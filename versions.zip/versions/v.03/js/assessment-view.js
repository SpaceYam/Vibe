
"use strict";

window.ExamView = {
  render() {
    const q = DB.questions[State.question];
    const answered = State.answers[q.id] !== undefined;
    const count = State.answered();
    const total = DB.questions.length;
    const progress = Math.round(count / total * 100);

    return `
      <div class="page-heading">
        <span class="badge badge-info">
          ${State.mode === "pre" ? "PRE-ASSESSMENT" : "FINAL ASSESSMENT"}
        </span>
        <h1>역량 평가</h1>
        <p>${DB.profiles.find(p => p.id === State.profile)?.name || ""}</p>
      </div>

      <div class="flex-between">
        <strong>시험 진행 상황</strong>
        <span>${count} / ${total} 문항 응답</span>
      </div>
      <div class="progress exam-progress">
        <div style="width:${progress}%"></div>
      </div>

      <section class="card question-card">
        <div class="flex-between">
          <span class="badge badge-info">${q.skill}</span>
          <span class="muted">${q.type} · ${q.score}점</span>
        </div>

        <h2 class="question-title">
          Q${String(q.id).padStart(3,"0")}. ${q.title}
        </h2>

        <div>
          ${q.options.map((option,i) => `
            <button class="question-option
              ${State.answers[q.id] === i ? "selected" : ""}"
              data-action="answer" data-index="${i}">
              <span class="option-letter">
                ${String.fromCharCode(65+i)}
              </span>
              <span>${option}</span>
              ${State.answers[q.id] === i ? "✓" : ""}
            </button>`).join("")}
        </div>

        <div class="flex-between mt-24">
          <span class="muted">
            ${answered ? "✓ 답변 저장 완료" : "답변을 선택해 주세요"}
          </span>
          <button class="btn btn-secondary"
            data-action="flag">
            ${State.flagged.includes(q.id) ? "🔖 검토 해제" : "⚑ 검토 표시"}
          </button>
        </div>

        <div class="flex-between mt-24">
          <button class="btn btn-secondary"
            data-action="prev"
            ${State.question === 0 ? "disabled" : ""}>
            ← 이전
          </button>
          <button class="btn btn-primary"
            data-action="next">
            ${State.question === total-1 ? "마지막 문제" : "다음 문제 →"}
          </button>
        </div>
      </section>

      <section class="card mt-24">
        <div class="flex-between">
          <h3>전체 문제 목록</h3>
          <span class="badge">AG GRID</span>
        </div>
        <div class="flex-between mt-16">
          <span class="badge badge-success">✓ 완료 ${count}</span>
          <span class="badge">미응답 ${total-count}</span>
          <span class="badge badge-warning">
            🔖 검토 ${State.flagged.length}
          </span>
        </div>
        <div id="question-grid"
          class="ag-theme-quartz exam-grid"></div>
        <p class="muted mt-16">
          문제 행을 클릭하면 해당 문항으로 이동합니다.
          응답 상태 표시는 읽기 전용입니다.
        </p>
      </section>

      <div class="flex-between mt-24">
        <span class="muted">답변은 브라우저에 자동 저장됩니다.</span>
        <button class="btn btn-primary"
          data-action="finish">시험 제출하기</button>
      </div>`;
  }
};
