
"use strict";

window.State = {
  page: "home",
  profile: null,
  mode: "pre",
  question: 0,
  answers: {},
  flagged: [],
  completed: [],
  before: null,
  after: null,
  course: 0,
  theme: "light",

  init() {
    const saved = Store.read();
    Object.assign(this, saved);

    this.theme = saved.theme || "light";
    this.applyTheme();
  },

  persist() {
    Store.save({
      profile: this.profile,
      mode: this.mode,
      question: this.question,
      answers: this.answers,
      flagged: this.flagged,
      completed: this.completed,
      before: this.before,
      after: this.after,
      course: this.course,
      theme: this.theme
    });
  },

  applyTheme() {
    document.documentElement.dataset.theme = this.theme;
  },

  toggleTheme() {
    this.theme = this.theme === "light" ? "dark" : "light";
    this.applyTheme();
    this.persist();
  },

  answered() {
    return Object.keys(this.answers).length;
  }
};
