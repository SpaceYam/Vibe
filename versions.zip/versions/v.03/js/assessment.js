
"use strict";

window.Assessment = {
  grid: null,

  start(mode) {
    State.mode = mode;
    State.question = 0;
    State.answers = {};
    State.flagged = [];
    State.page = "assessment";
    State.persist();
    App.render();
  },

  select(index) {
    State.question = Math.max(
      0, Math.min(index, DB.questions.length - 1)
    );
    State.persist();
    App.render();
  },

  answer(index) {
    const q = DB.questions[State.question];
    State.answers[q.id] = index;
    State.persist();
    App.render();
  },

  flag(id) {
    State.flagged = State.flagged.includes(id)
      ? State.flagged.filter(x => x !== id)
      : [...State.flagged, id];

    State.persist();
    App.render();
  },

  score() {
    let correct = 0;
    DB.questions.forEach(q => {
      if (State.answers[q.id] === q.answer) correct++;
    });
    return Math.round(correct / DB.questions.length * 100);
  },

  finish() {
    const unanswered = DB.questions.filter(
      q => State.answers[q.id] === undefined
    );

    if (unanswered.length &&
        !confirm(`${unanswered.length}개 문제가 미응답입니다. 제출할까요?`)) {
      return;
    }

    const result = {
      score: this.score(),
      date: new Date().toISOString(),
      answers: {...State.answers}
    };

    if (State.mode === "pre") {
      State.before = result;
      State.page = "dashboard";
    } else {
      State.after = result;
      State.page = "report";
    }

    State.persist();
    App.render();
  },

  initGrid() {
    const el = document.getElementById("question-grid");
    if (!el || !window.agGrid) return;

    const rows = DB.questions.map((q, i) => ({
      id: q.id,
      number: `Q${String(q.id).padStart(3,"0")}`,
      skill: q.skill,
      type: q.type,
      status: State.answers[q.id] !== undefined,
      flag: State.flagged.includes(q.id),
      index: i
    }));

    if (this.grid) {
      this.grid.destroy();
      this.grid = null;
    }

    const options = {
      rowData: rows,
      theme: agGrid.themeQuartz,
      columnDefs: [
        {field:"number",headerName:"번호",width:100},
        {field:"skill",headerName:"역량",flex:1},
        {field:"type",headerName:"유형",width:110},
        {
          field:"status",
          headerName:"응답 상태",
          width:120,
          cellRenderer: p => p.value
            ? '<span class="badge badge-success">✓ 완료</span>'
            : '<span class="muted">○ 미응답</span>'
        },
        {
          field:"flag",
          headerName:"검토",
          width:90,
          cellRenderer: p => p.value ? "🔖" : "—"
        }
      ],
      getRowId: p => String(p.data.id),
      rowSelection: {
        mode: "singleRow",
        checkboxes: false,
        enableClickSelection: false
      },
      onRowClicked: p => this.select(p.data.index),
      getRowClass: p => p.data.index === State.question
        ? "current-question" : ""
    };

    this.grid = agGrid.createGrid(el, options);
  }
};
