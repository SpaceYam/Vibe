
"use strict";

window.App = {
  render() {
    let content = "";

    switch (State.page) {
      case "home":
        content = Views.home();
        break;
      case "profile":
        content = Views.profile();
        break;
      case "dashboard":
        content = Views.dashboard();
        break;
      case "assessment":
        content = ExamView.render();
        break;
      case "learning":
        content = LearningView.render();
        break;
      case "report":
        content = ReportView.render();
        break;
      default:
        content = Views.home();
    }

    document.getElementById("app").innerHTML =
      Views.shell(content);

    if (State.page === "assessment") {
      Assessment.initGrid();
    }
  },

  navigate(page) {
    State.page = page;
    State.persist();
    this.render();
  },

  init() {
    State.init();

    document.addEventListener("click", e => {
      const target = e.target.closest("[data-action]");
      if (!target) return;

      const action = target.dataset.action;
      const id = target.dataset.id;
      const index = Number(target.dataset.index);

      switch (action) {
        case "home":
          this.navigate("home");
          break;

        case "profile":
          this.navigate("profile");
          break;

        case "dashboard":
          this.navigate("dashboard");
          break;

        case "report":
          this.navigate("report");
          break;

        case "learning":
          this.navigate("learning");
          break;

        case "theme":
          State.toggleTheme();
          this.render();
          break;

        case "select-profile":
          State.profile = id;
          State.before = null;
          State.after = null;
          Store.set("lessons", []);
          Assessment.start("pre");
          break;

        case "pretest":
          Assessment.start("pre");
          break;

        case "finaltest":
          if (Learning.progress() === 100) {
            Assessment.start("final");
          }
          break;

        case "answer":
          Assessment.answer(index);
          break;

        case "prev":
          Assessment.select(State.question - 1);
          break;

        case "next":
          Assessment.select(State.question + 1);
          break;

        case "flag":
          Assessment.flag(
            DB.questions[State.question].id
          );
          break;

        case "finish":
          Assessment.finish();
          break;

        case "lesson":
          if (confirm("이 학습 단계를 완료 처리할까요?")) {
            Learning.complete(Number(id));
          }
          break;
      }
    });

    this.render();
  }
};

document.addEventListener("DOMContentLoaded", () => {
  App.init();
});
