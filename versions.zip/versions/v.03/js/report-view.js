
"use strict";

window.ReportView = {
  render() {
    const before = State.before;
    const after = State.after;

    if (!before) {
      return `<div class="card empty-state">
        사전 평가 결과가 없습니다.
      </div>`;
    }

    const change = after ? after.score - before.score : 0;

    return `
      <div class="page-heading">
        <span class="badge badge-success">SKILL GROWTH REPORT</span>
        <h1>나의 역량 성장 보고서</h1>
        <p>사전 평가와 최종 평가를 비교합니다.</p>
      </div>

      <div class="grid grid-2">
        <div class="card">
          <p>BEFORE</p>
          <div class="report-score">${before.score}</div>
          <span class="muted">사전 평가 / 100</span>
        </div>
        <div class="card">
          <p>AFTER</p>
          <div class="report-score">
            ${after ? after.score : "--"}
          </div>
          <span class="muted">최종 평가 / 100</span>
        </div>
      </div>

      ${after ? `
        <div class="card mt-24">
          <h3>총 역량 변화</h3>
          <div class="report-score">
            ${change > 0 ? "+" : ""}${change}
          </div>
          <p>동일한 평가 기준에 따른 점수 변화</p>
        </div>` : `
        <div class="card mt-24">
          <h3>최종 평가 대기 중</h3>
          <p>교육과정을 완료하고 최종 평가를 진행해 주세요.</p>
        </div>`}

      <div class="card mt-24">
        <h3>직무 스킬 인벤토리</h3>
        ${DB.profiles.find(p => p.id === State.profile)?.skills.map((s,i) => {
          const base = before.score;
          const current = after ? Math.min(100, after.score) : base;
          return `
            <div class="skill-row">
              <span>${s}</span>
              <div class="skill-track">
                <div style="width:${current}%"></div>
              </div>
              <strong>${current}</strong>
            </div>`;
        }).join("") || ""}
        <p class="muted mt-16">
          현재 프로토타입은 전체 점수를 역량 항목에 동일하게 표시하는 예시입니다.
          실제 직무 역량 점수는 항목별 평가 문항과 채점 근거를 연결해야 합니다.
        </p>
      </div>

      <button class="btn btn-secondary mt-24"
        data-action="home">홈으로 돌아가기</button>`;
  }
};
