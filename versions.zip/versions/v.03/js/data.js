
"use strict";

window.DB = {
  profiles: [
    {
      id: "frontend",
      name: "Frontend Developer",
      icon: "🎨",
      desc: "웹 UI 및 프론트엔드 개발",
      skills: ["HTML/CSS","JavaScript","UI/UX","React","Debugging"]
    },
    {
      id: "backend",
      name: "Backend Developer",
      icon: "⚙️",
      desc: "서버 및 데이터 처리",
      skills: ["API","Database","JavaScript","Security","Testing"]
    },
    {
      id: "ai",
      name: "AI-Assisted Developer",
      icon: "🤖",
      desc: "AI 협업 기반 소프트웨어 개발",
      skills: ["AI 활용","Prompt Design","JavaScript","Debugging","Architecture"]
    },
    {
      id: "prompt",
      name: "Prompt Engineer",
      icon: "✍️",
      desc: "AI 프롬프트 설계 및 활용",
      skills: ["Prompt Design","AI 활용","Evaluation","Automation"]
    },
    {
      id: "fullstack",
      name: "Full-Stack Developer",
      icon: "💻",
      desc: "프론트엔드 및 백엔드 통합",
      skills: ["HTML/CSS","JavaScript","API","Database","Architecture"]
    },
    {
      id: "qa",
      name: "QA Engineer",
      icon: "🔍",
      desc: "소프트웨어 품질 및 테스트",
      skills: ["Testing","Debugging","Automation","Documentation"]
    }
  ],

  questions: [
    {
      id: 1, skill: "JavaScript", type: "객관식", score: 10,
      title: "JavaScript에서 배열의 각 요소를 변환하여 새로운 배열을 반환하는 메서드는?",
      options: ["push()","pop()","map()","splice()"],
      answer: 2,
      explanation: "map()은 각 요소에 콜백을 적용하여 새로운 배열을 반환합니다."
    },
    {
      id: 2, skill: "HTML/CSS", type: "객관식", score: 10,
      title: "HTML에서 문서의 주요 콘텐츠를 나타내는 시맨틱 태그는?",
      options: ["div","main","span","style"],
      answer: 1,
      explanation: "main은 문서의 주요 콘텐츠 영역을 나타냅니다."
    },
    {
      id: 3, skill: "JavaScript", type: "객관식", score: 10,
      title: "const로 선언한 객체의 속성을 변경할 수 있는가?",
      options: ["불가능하다","가능하다","배열만 가능하다","함수만 가능하다"],
      answer: 1,
      explanation: "const는 변수 재할당을 막지만 객체 내부 속성 변경은 허용합니다."
    },
    {
      id: 4, skill: "AI 활용", type: "객관식", score: 10,
      title: "AI에게 복잡한 개발 작업을 요청할 때 가장 효과적인 방법은?",
      options: [
        "짧은 명령만 전달한다",
        "목표와 제약조건, 출력 형식을 명시한다",
        "모든 작업을 한 번에 요청한다",
        "맥락을 제공하지 않는다"
      ],
      answer: 1,
      explanation: "목표, 맥락, 제약조건, 결과 형식을 구체화하면 작업 품질을 개선할 수 있습니다."
    },
    {
      id: 5, skill: "Debugging", type: "객관식", score: 10,
      title: "프로그램에서 오류가 발생했을 때 가장 먼저 할 일은?",
      options: [
        "코드를 모두 삭제한다",
        "오류 메시지와 재현 조건을 확인한다",
        "무작정 코드를 수정한다",
        "프로그램을 다시 설치한다"
      ],
      answer: 1,
      explanation: "오류를 재현하고 원인을 확인하는 것이 체계적인 디버깅의 출발점입니다."
    },
    {
      id: 6, skill: "Prompt Design", type: "객관식", score: 10,
      title: "프롬프트에서 출력 형식을 지정하는 주된 목적은?",
      options: [
        "AI의 처리 속도를 높이기 위해",
        "결과의 구조와 일관성을 높이기 위해",
        "모델을 변경하기 위해",
        "질문 길이를 줄이기 위해"
      ],
      answer: 1,
      explanation: "출력 형식을 명시하면 결과를 원하는 구조로 얻기 쉬워집니다."
    },
    {
      id: 7, skill: "UI/UX", type: "객관식", score: 10,
      title: "접근성 높은 버튼을 설계할 때 중요한 것은?",
      options: [
        "색상만으로 상태를 표현한다",
        "충분한 대비와 명확한 이름을 제공한다",
        "버튼을 최대한 작게 만든다",
        "키보드 접근을 제한한다"
      ],
      answer: 1,
      explanation: "명확한 레이블과 대비, 키보드 접근성을 함께 고려해야 합니다."
    },
    {
      id: 8, skill: "Testing", type: "객관식", score: 10,
      title: "단위 테스트(Unit Test)의 주요 목적은?",
      options: [
        "전체 서비스를 디자인한다",
        "개별 함수나 모듈의 동작을 검증한다",
        "서버를 배포한다",
        "사용자 인터뷰를 수행한다"
      ],
      answer: 1,
      explanation: "단위 테스트는 작은 코드 단위의 예상 동작을 검증합니다."
    }
  ],

  courses: [
    {id:1,title:"AI와 개발 환경 이해",desc:"AI 개발 도구와 기본 개념",time:"30분"},
    {id:2,title:"프롬프트 엔지니어링",desc:"효과적인 AI 협업 방법",time:"45분"},
    {id:3,title:"JavaScript 실전 기초",desc:"웹 개발 핵심 문법",time:"60분"},
    {id:4,title:"디버깅과 문제 해결",desc:"오류 분석 및 수정",time:"45분"},
    {id:5,title:"실전 프로젝트 제작",desc:"AI를 활용한 웹 서비스 구축",time:"90분"}
  ],

  skills: [
    "HTML/CSS","JavaScript","AI 활용",
    "Prompt Design","Debugging","UI/UX",
    "Testing","Architecture"
  ]
};
