
"use strict";

window.Views = {
  shell(content) {
    return `
      <div class="shell">
        <header class="topbar">
          <a href="#" class="logo" data-action="home">
            VIBE<span>SCHOOL</span>
          </a>
          <nav class="nav">
            <button data-action="home">홈</button>
            <button data-action="dashboard">학습</button>
            <button data-action="report">결과 보고서</button>
          </nav>
          <div class="top-actions">
            <button class="btn btn-secondary"
              data-action="theme">◐</button>
          </div>
        </header>
        <main class="main">${content}</main>
        <footer class="footer">
          VIBE SCHOOL © 2026 · LEARN AND BUILD WITH AI
        </footer>
      </div>`;
  },

  home() {
    return `
      <section class="hero">
        <span class="badge badge-info">AI LEARNING PLATFORM</span>
        <h1>AI와 함께 성장하는<br>나만의 개발 역량</h1>
        <p>현재 역량을 진단하고, 나에게 맞는 교육과정을 경험하세요.</p>
        <button class="btn btn-primary mt-24"
          data-action="profile">
          나의 직무 프로파일 설정 →
        </button>
      </section>

      <div class="grid grid-3 mt-24">
        ${[
          ["01","ASSESS","현재 역량 진단"],
          ["02","LEARN","개인화 학습"],
          ["03","GROW","성장 결과 분석"]
        ].map(x => `
          <article class="card">
            <span class="badge">${x[0]}</span>
            <h3 class="mt-16">${x[1]}</h3>
            <p>${x[2]}</p>
          </article>`).join("")}
      </div>`;
  },

  profile() {
    return `
      <div class="page-heading">
        <span class="badge badge-info">STEP 01</span>
        <h1>어떤 직무를 목표로 하시나요?</h1>
        <p>희망 직무를 선택하면 해당 직무의 역량 기준으로 진단합니다.</p>
      </div>
      <div class="grid grid-3">
        ${DB.profiles.map(p => `
          <article class="card profile-card"
            data-action="select-profile" data-id="${p.id}">
            <div class="profile-icon">${p.icon}</div>
            <h3 class="mt-16">${p.name}</h3>
            <p>${p.desc}</p>
            <div class="mt-16">
              <span class="badge badge-info">직무 선택 →</span>
            </div>
          </article>`).join("")}
      </div>
      <div class="card mt-24">
        <h3>아직 직무를 정하지 못했나요?</h3>
        <p>공통 AI·디지털 역량부터 진단할 수 있습니다.</p>
        <button class="btn btn-secondary mt-16"
          data-action="select-profile" data-id="ai">
          공통 역량 진단하기
        </button>
      </div>`;
  },

  dashboard() {
    const profile = DB.profiles.find(
      p => p.id === State.profile
    );
    const before = State.before;

    return `
      <div class="page-heading">
        <span class="badge badge-success">MY LEARNING</span>
        <h1>학습 대시보드</h1>
        <p>${profile?.name || "직무 미선택"}</p>
      </div>

      <div class="grid grid-3">
        <div class="card">
          <p>사전 진단 점수</p>
          <div class="report-score">
            ${before ? before.score : "--"}
          </div>
        </div>
        <div class="card">
          <p>학습 진행률</p>
          <div class="report-score">${Learning.progress()}%</div>
        </div>
        <div class="card">
          <p>학습 콘텐츠</p>
          <div class="report-score">
            ${Learning.curriculum().length}
          </div>
        </div>
      </div>

      <div class="card mt-24">
        <h3>나의 학습 워크플로우</h3>
        <p class="mt-16">현재 역량을 기준으로 교육과정을 진행하세요.</p>
        <div class="progress mt-16">
          <div style="width:${Learning.progress()}%"></div>
        </div>
        <button class="btn btn-primary mt-24"
          data-action="learning">
          교육과정 확인하기 →
        </button>
      </div>

      <div class="card mt-24">
        <h3>평가 및 성장 분석</h3>
        <p>사전 진단과 최종 평가 결과를 비교합니다.</p>
        ${before
          ? `<button class="btn btn-secondary mt-16"
              data-action="report">사전 평가 결과 확인</button>`
          : `<button class="btn btn-primary mt-16"
              data-action="pretest">사전 역량 진단 시작</button>`}
      </div>`;
  }
};
