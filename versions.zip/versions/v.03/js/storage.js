
"use strict";

window.Store = {
  key: "vibe-school-v4",

  read() {
    try {
      return JSON.parse(localStorage.getItem(this.key)) || {};
    } catch {
      return {};
    }
  },

  save(data) {
    try {
      localStorage.setItem(this.key, JSON.stringify(data));
      return true;
    } catch {
      return false;
    }
  },

  get(key, fallback = null) {
    return this.read()[key] ?? fallback;
  },

  set(key, value) {
    const data = this.read();
    data[key] = value;
    return this.save(data);
  },

  clear() {
    localStorage.removeItem(this.key);
  }
};
