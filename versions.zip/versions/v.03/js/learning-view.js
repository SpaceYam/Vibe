
"use strict";

window.LearningView = {
  render() {
    const courses = Learning.curriculum();

    return `
      <div class="page-heading">
        <span class="badge badge-info">PERSONALIZED CURRICULUM</span>
        <h1>나의 맞춤형 교육과정</h1>
        <p>진단된 역량을 바탕으로 학습을 진행합니다.</p>
      </div>

      <div class="card">
        <div class="flex-between">
          <h3>전체 학습 진행률</h3>
          <strong>${Learning.progress()}%</strong>
        </div>
        <div class="progress mt-16">
          <div style="width:${Learning.progress()}%"></div>
        </div>
      </div>

      <div class="card mt-24">
        ${courses.map((c,i) => {
          const done = Learning.isComplete(c.id);
          return `
            <div class="lesson-item">
              <div>
                <span class="badge">STEP ${i+1}</span>
                <h3 class="mt-16">${c.title}</h3>
                <p>${c.desc} · ${c.time}</p>
              </div>
              <button class="btn ${done ? "btn-secondary" : "btn-primary"}"
                data-action="lesson" data-id="${c.id}">
                ${done ? "✓ 완료" : "학습 완료"}
              </button>
            </div>`;
        }).join("")}
      </div>

      <div class="card mt-24">
        <h3>교육과정 최종 평가</h3>
        <p>학습을 완료하면 최종 역량 평가를 진행할 수 있습니다.</p>
        <button class="btn btn-primary mt-16"
          data-action="finaltest"
          ${Learning.progress() < 100 ? "disabled" : ""}>
          최종 평가 시작 →
        </button>
      </div>`;
  }
};
