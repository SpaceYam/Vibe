
"use strict";

window.Learning = {
  curriculum() {
    const profile = DB.profiles.find(
      p => p.id === State.profile
    );

    if (!profile) return DB.courses;

    return DB.courses.filter((course, i) => {
      if (profile.id === "prompt") return i !== 2;
      if (profile.id === "qa") return i !== 1;
      return true;
    });
  },

  complete(id) {
    const list = Store.get("lessons", []);
    if (!list.includes(id)) list.push(id);
    Store.set("lessons", list);
    App.render();
  },

  isComplete(id) {
    return Store.get("lessons", []).includes(id);
  },

  progress() {
    const lessons = this.curriculum();
    const done = lessons.filter(
      c => this.isComplete(c.id)
    ).length;

    return Math.round(done / lessons.length * 100);
  }
};
