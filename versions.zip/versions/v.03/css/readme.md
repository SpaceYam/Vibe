
# VIBE SCHOOL 4.0

AI Competency Assessment & Personalized Learning Platform

## 주요 기능

- 직무 프로파일 선택
- 사전 역량 진단
- AG Grid 기반 문제 네비게이션
- 답변 자동 저장
- 검토 문제 표시
- 개인화 교육과정
- 최종 역량 평가
- BEFORE & AFTER 결과 보고서
- Light / Dark 테마

## 기술 스택

- HTML5
- CSS3
- Vanilla JavaScript
- AG Grid Community 33.3.2
- Browser LocalStorage

## 실행 방법

1. 프로젝트 폴더를 생성합니다.
2. 제공된 파일을 각 폴더에 저장합니다.
3. VS Code에서 프로젝트를 엽니다.
4. Live Server로 index.html을 실행합니다.
5. 인터넷 연결을 확인합니다.

AG Grid는 CDN을 사용합니다.

## 데이터 저장

현재 버전은 LocalStorage를 사용합니다.

실제 다중 사용자 서비스 운영 시에는
백엔드 및 데이터베이스 연동이 필요합니다.

## 주의사항

현재 평가 문항과 결과 데이터는 프로토타입용입니다.
실제 직무 역량 인증에는 검증된 평가 문항,
채점 루브릭, 시험 동등화 및 신뢰도 검증이 필요합니다.
