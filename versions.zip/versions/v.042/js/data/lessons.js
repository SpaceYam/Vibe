
"use strict";

const contentGroups = [
 LessonContent.ai,
 LessonContent.programming,
 LessonContent.transformer,
 LessonContent.prompt,
 LessonContent.vibe,
 LessonContent.llm,
 LessonContent.agent,
 LessonContent.deployment
];

window.Lessons = Courses.flatMap((course, ci) =>
 course.lessons.map((title, li) => {
  const d = contentGroups[ci][li];

  if (!d) {
   throw new Error(`학습 데이터 누락: ${course.title}/${title}`);
  }

  return {
   id:ci*5+li+1,
   courseId:course.id,
   title,
   objective:d.concepts[0],
   concepts:d.concepts,
   theory:d.concepts,
   code:d.example,
   practice:d.practice,
   challenge:d.challenge,
   checkpoint:d.checkpoint
  };
 })
);
