
"use strict";

window.Courses = [
{
 id:1,
 title:"AI와 인공지능 기초",
 desc:"AI, 머신러닝, 딥러닝, 생성형 AI의 원리",
 lessons:[
  "인공지능의 역사와 발전",
  "머신러닝의 원리",
  "생성형 AI와 LLM",
  "AI 모델의 학습과 추론",
  "AI 윤리와 보안"
 ]
},
{
 id:2,
 title:"프로그래밍과 웹 개발",
 desc:"Python, JavaScript, 웹 구조와 API",
 lessons:[
  "Python 프로그래밍 기초",
  "JavaScript 프로그래밍",
  "자료구조와 알고리즘",
  "HTML CSS 웹 구조",
  "HTTP와 REST API"
 ]
},
{
 id:3,
 title:"Transformer와 LLM 구조",
 desc:"토큰, 임베딩, Attention, Transformer",
 lessons:[
  "토큰과 토크나이저",
  "Embedding과 벡터",
  "Self Attention",
  "Transformer 아키텍처",
  "LLM 추론과 생성"
 ]
},
{
 id:4,
 title:"프롬프트 엔지니어링",
 desc:"프롬프트 설계와 평가",
 lessons:[
  "프롬프트 설계 원칙",
  "Role Context Constraint",
  "Few Shot Prompting",
  "구조화 출력과 JSON",
  "프롬프트 평가와 개선"
 ]
},
{
 id:5,
 title:"AI Vibe Coding",
 desc:"AI와 협업하는 소프트웨어 개발",
 lessons:[
  "Vibe Coding 이해",
  "요구사항 분석",
  "AI 코드 생성과 수정",
  "디버깅과 오류 해결",
  "리팩터링과 컨텍스트 관리"
 ]
},
{
 id:6,
 title:"LLM 애플리케이션",
 desc:"API, Embedding, RAG, 멀티모달",
 lessons:[
  "LLM API 활용",
  "Embedding과 Vector DB",
  "RAG 시스템 구축",
  "멀티모달 AI",
  "LLM 품질 평가"
 ]
},
{
 id:7,
 title:"AI Agent 개발",
 desc:"Tool Calling, Workflow, MCP",
 lessons:[
  "AI Agent 구조",
  "Function Calling",
  "Agent Workflow",
  "MCP 프로토콜",
  "Agent 안전성과 제어"
 ]
},
{
 id:8,
 title:"테스트와 배포",
 desc:"품질, 보안, Docker, 프로젝트",
 lessons:[
  "테스트와 검증",
  "AI 애플리케이션 보안",
  "Docker와 컨테이너",
  "서비스 배포와 운영",
  "최종 AI 프로젝트"
 ]
}
];
