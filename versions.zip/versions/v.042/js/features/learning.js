
"use strict";

window.Learning={
 complete(id,note){
  if(note.trim().length<5){
   App.toast("실습 기록을 작성하세요.");
   return;
  }

  if(!State.completed.includes(id)){
   State.completed.push(id);
  }

  State.notes[id]=note;
  State.persist();

  Router.go("learning");
  App.toast("학습 진도를 저장했습니다.");
 },

 render(){
  const priority=Progress.priority();

  return `
  <section class="card">
   <span class="tag">LEARNING ROADMAP</span>
   <h1>AI Vibe Developer 교육과정</h1>
   <b>학습 진행률 ${Progress.percent()}%</b>
   <div class="progress">
    <span style="width:${Progress.percent()}%"></span>
   </div>
  </section>

  ${priority.map((x,i)=>`
   <section class="card ${x.score<80?"recommended":""}">
    <h2>${x.course.title}</h2>
    <p>진단 점수 ${x.score}점</p>

    ${Lessons.filter(l=>l.courseId===x.course.id)
     .map(l=>`
      <div class="lesson-row">
       <div>
        <b>${l.title}</b>
        <small>${Progress.done(l.id)?"✓ 완료":"학습 필요"}</small>
       </div>
       <button class="btn outline"
        data-action="lesson" data-id="${l.id}">
        학습하기
       </button>
      </div>
     `).join("")}
   </section>
  `).join("")}

  <section class="card">
   <button class="btn primary" data-action="pre">
    역량 재진단
   </button>
   <button class="btn teal" data-action="final"
    ${Progress.percent()<100?"disabled":""}>
    사후 평가
   </button>
  </section>`;
 }
};
