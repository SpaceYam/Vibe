
"use strict";

window.PromptLab={
 generate(){
  const get=id=>document.getElementById(id).value.trim();

  const role=get("role");
  const goal=get("goal");
  const language=get("language");
  const context=get("context");
  const constraints=get("constraints");
  const output=get("output");

  const prompt=`역할: ${role}
목표: ${goal}
개발 언어: ${language}
프로젝트 맥락: ${context}
제약 조건: ${constraints}
출력 형식: ${output}

요구사항을 분석하고 불명확한 부분은 먼저 질문하세요.
기존 기능을 임의로 제거하지 말고 변경 범위를 지키세요.
코드를 작성한 뒤 테스트 방법과 검증 기준을 제시하세요.`;

  document.getElementById("generatedPrompt").value=prompt;
 },

 copy(){
  const value=document.getElementById("generatedPrompt").value;
  navigator.clipboard.writeText(value)
   .then(()=>App.toast("프롬프트를 복사했습니다."))
   .catch(()=>App.toast("복사할 수 없습니다."));
 },

 render(){
  return `
  <section class="card">
   <h1>프롬프트 실습실</h1>
   <p>개발 목표와 환경을 입력해 프롬프트를 생성하세요.</p>

   <label>AI 역할</label>
   <input id="role" value="시니어 AI 풀스택 개발자">

   <label>개발 목표</label>
   <input id="goal" placeholder="예: RAG 기반 문서 검색 서비스">

   <label>개발 언어</label>
   <select id="language">
    <option>Python + JavaScript</option>
    <option>Python</option>
    <option>JavaScript</option>
   </select>

   <label>프로젝트 맥락</label>
   <textarea id="context"></textarea>

   <label>제약 조건</label>
   <textarea id="constraints"></textarea>

   <label>출력 형식</label>
   <select id="output">
    <option>파일별 전체 코드와 설명</option>
    <option>설계 및 구현 계획</option>
    <option>코드 리뷰 및 개선안</option>
   </select>

   <button class="btn primary" data-action="generate-prompt">
    프롬프트 생성
   </button>

   <h3>생성 결과</h3>
   <textarea id="generatedPrompt" rows="12"></textarea>

   <button class="btn teal" data-action="copy-prompt">
    복사하기
   </button>
  </section>`;
 }
};
