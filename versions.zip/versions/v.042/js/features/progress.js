
"use strict";

window.Progress={
 get total(){return Lessons.length;},

 percent(){
  return Math.round(
   State.completed.length/this.total*100
  );
 },

 done(id){
  return State.completed.includes(id);
 },

 priority(){
  if(!State.before)return [];

  return Courses.map(c=>({
   course:c,
   score:State.before.domains[c.title]?.score??0
  })).sort((a,b)=>a.score-b.score);
 },

 recommendedLessons(){
  return this.priority().flatMap(x=>
   Lessons.filter(l=>
    l.courseId===x.course.id&&!this.done(l.id)
   )
  );
 }
};
