
"use strict";

window.Store={
 key:"vibe-school-v2",

 load(){
  try{
   return JSON.parse(
    localStorage.getItem(this.key)
   )||{};
  }catch(e){
   console.error("저장 데이터 오류",e);
   return {};
  }
 },

 save(data){
  try{
   localStorage.setItem(
    this.key,
    JSON.stringify(data)
   );
  }catch(e){
   console.error("저장 실패",e);
  }
 },

 set(key,value){
  const data=this.load();
  data[key]=value;
  this.save(data);
 }
};
