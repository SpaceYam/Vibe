
"use strict";

window.Router={
 go(page){
  State.page=page;
  App.render();
 },

 lesson(id){
  State.lesson=id;
  this.go("lesson");
 }
};
