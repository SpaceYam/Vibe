
"use strict";

window.State={
 page:"home",
 profile:null,
 completed:[],
 notes:{},
 before:null,
 after:null,
 answers:{},
 examMode:"diagnostic",
 question:0,
 lesson:1,
 examStarted:{},
 examElapsed:{},
 assessmentHistory:[],

 init(){
  const saved=Store.load();
  Object.assign(this,saved);

  this.answers={};
  this.examStarted={};
  this.examElapsed={};

  if(!Array.isArray(this.completed))this.completed=[];
  if(!Array.isArray(this.assessmentHistory))this.assessmentHistory=[];
  if(!this.notes)this.notes={};
 },

 persist(){
  Store.save({
   profile:this.profile,
   completed:this.completed,
   notes:this.notes,
   before:this.before,
   after:this.after,
   assessmentHistory:this.assessmentHistory
  });
 },

 resetExam(mode="diagnostic"){
  this.examMode=mode;
  this.answers={};
  this.examStarted={};
  this.examElapsed={};
  this.question=0;
 }
};
