
"use strict";

window.App={
 confirmAction:null,
 toastTimer:null,
 charts:[],

 escape(v){
  return String(v??"").replace(/[&<>"']/g,c=>({
   "&":"&amp;","<":"&lt;",">":"&gt;",
   '"':"&quot;","'":"&#39;"
  })[c]);
 },

 toast(message){
  const el=document.getElementById("toast");
  el.textContent=message;
  el.classList.add("show");
  clearTimeout(this.toastTimer);
  this.toastTimer=setTimeout(
   ()=>el.classList.remove("show"),2500
  );
 },

 modal(title,message,fn){
  this.confirmAction=fn;
  document.getElementById("modal").innerHTML=`
   <div class="modal-box">
    <h2>${this.escape(title)}</h2>
    <p>${this.escape(message)}</p>
    <div class="actions">
     <button class="btn outline" data-action="cancel">취소</button>
     <button class="btn primary" data-action="confirm">확인</button>
    </div>
   </div>`;
  document.getElementById("modal").classList.add("show");
 },

 closeModal(){
  document.getElementById("modal").classList.remove("show");
  this.confirmAction=null;
 },

 updateTimer(left){
  const q=Quizzes[State.question];
  const t=document.getElementById("timerText");
  const b=document.getElementById("timerBar");

  if(t)t.textContent=Math.ceil(left)+"초";

  if(b){
   const pct=Math.max(0,left/q.seconds*100);
   b.style.width=pct+"%";
   b.classList.toggle("danger",pct<25);
  }
 },

 updateQuestion(){
  const area=document.getElementById("questionArea");
  if(area)area.innerHTML=AssessmentView.question();

  const count=Object.keys(State.answers).length;
  const label=document.getElementById("examCount");
  const bar=document.getElementById("examBar");

  if(label)label.textContent=`${count}/${Quizzes.length}`;
  if(bar)bar.style.width=count/Quizzes.length*100+"%";

  this.updateTimer(Assessment.remaining(State.question));
 },

 render(){
  Assessment.destroy();

  this.charts.forEach(c=>c.destroy());
  this.charts=[];

  if(!State.profile)State.page="profile";

  const pages={
   profile:HomeView.profile(),
   home:HomeView.render(),
   learning:Learning.render(),
   lesson:LessonView.render(),
   assessment:AssessmentView.render(),
   prompt:PromptLab.render(),
   report:ReportView.render()
  };

  document.getElementById("app").innerHTML=`
   <header class="topbar">
    <a class="logo" href="#" data-action="home">
     VIBE SCHOOL
    </a>
    <nav>
     <button data-action="home">홈</button>
     <button data-action="learning">교육과정</button>
     <button data-action="prompt">프롬프트</button>
     <button data-action="report">리포트</button>
    </nav>
   </header>
   <main>${pages[State.page]||pages.home}</main>
   <footer>VIBE SCHOOL · AI VIBE DEVELOPER ACADEMY</footer>`;

  if(State.page==="assessment"){
   Assessment.grid=agGrid.createGrid(
    document.getElementById("questionGrid"),{
     getRowId:p=>String(p.data.no),

     rowData:Quizzes.map((q,i)=>({
      no:i+1,
      domain:q.domain,
      question:q.question,
      status:State.answers[i]===-1
       ?"시간 초과"
       :State.answers[i]!==undefined
        ?"✓ 완료":"미완료"
     })),

     columnDefs:[
      {field:"no",headerName:"번호",width:75},
      {field:"domain",headerName:"영역",width:150},
      {field:"question",headerName:"문제",flex:1},
      {field:"status",headerName:"상태",width:100}
     ],

     defaultColDef:{
      sortable:true,
      resizable:true
     },

     onRowClicked:p=>{
      Assessment.select(p.data.no-1);
     },

     suppressCellFocus:true
    }
   );
  }

  if(State.page==="report")ReportView.init();
 },

 init(){
  State.init();
  Events.init();
  this.render();
 }
};

document.addEventListener("DOMContentLoaded",()=>App.init());
