
"use strict";

window.HomeView={
 profile(){
  return `
  <section class="card">
   <h1>AI 개발 학습 프로필</h1>
   <p>학습 목표를 설정해 주세요.</p>

   <label>이름</label>
   <input id="pName" placeholder="이름">

   <label>최종 목표</label>
   <select id="pGoal">
    <option>AI 서비스 개발</option>
    <option>AI 개발자 취업</option>
    <option>업무 자동화</option>
    <option>AI Agent 개발</option>
    <option>AI 사업 시작</option>
   </select>

   <label>개발 경험</label>
   <select id="pDev">
    <option>개발 경험 없음</option>
    <option>기초 문법 학습</option>
    <option>프로젝트 경험</option>
    <option>실무 경험</option>
   </select>

   <label>AI 활용 경험</label>
   <select id="pAI">
    <option>거의 없음</option>
    <option>ChatGPT 기본 사용</option>
    <option>프롬프트 설계</option>
    <option>AI API 사용</option>
    <option>AI 서비스 개발</option>
   </select>

   <label>최종 프로젝트 목표</label>
   <textarea id="pProject"></textarea>

   <button class="btn primary" data-action="save-profile">
    프로필 생성
   </button>
  </section>`;
 },

 render(){
  if(!State.profile)return this.profile();

  return `
  <section class="hero">
   <span class="tag">VIBE SCHOOL</span>
   <h1>AI를 이해하고, AI와 함께 개발하세요.</h1>
   <p>프로그래밍부터 LLM, Agent, 배포까지.</p>
  </section>

  <section class="card">
   <h2>${App.escape(State.profile.name)}님</h2>
   <p>목표: ${App.escape(State.profile.goal)}</p>
   <p>프로젝트: ${App.escape(State.profile.project)}</p>

   <b>학습 진행도 ${Progress.percent()}%</b>
   <div class="progress">
    <span style="width:${Progress.percent()}%"></span>
   </div>

   <div class="grid">
    <div class="stat">
     <strong>${State.before?.total??"-"}</strong>
     진단 점수
    </div>
    <div class="stat">
     <strong>${Progress.percent()}%</strong>
     학습 진도
    </div>
    <div class="stat">
     <strong>${State.after?.total??"-"}</strong>
     사후 점수
    </div>
   </div>
  </section>

  <section class="card">
   <div class="actions">
    <button class="btn primary" data-action="pre">역량 진단</button>
    <button class="btn teal" data-action="learning">교육과정</button>
    <button class="btn outline" data-action="prompt">프롬프트 실습</button>
    <button class="btn outline" data-action="report">학습 리포트</button>
   </div>
  </section>`;
 }
};
