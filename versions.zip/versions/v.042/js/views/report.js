
"use strict";

window.ReportView={
 render(){
  const b=State.before;
  const a=State.after;

  return `
  <section class="card">
   <h1>학습 역량 리포트</h1>
   <p>진단 결과와 학습 성취도를 비교합니다.</p>

   ${!b?`
    <p>아직 진단 결과가 없습니다.</p>
    <button class="btn primary" data-action="pre">
     역량 진단
    </button>`:`
    <div class="grid">
     <div class="stat">
      <strong>${b.total}점</strong>
      사전 진단
     </div>
     <div class="stat">
      <strong>${a?a.total+"점":"미실시"}</strong>
      사후 진단
     </div>
     <div class="stat">
      <strong>${a?(a.total-b.total>=0?"+":"")+(a.total-b.total)+"점":"-"}</strong>
      변화
     </div>
    </div>

    <canvas id="scoreChart"></canvas>
    <h2>영역별 역량 변화</h2>
    <canvas id="skillChart"></canvas>

    ${Object.entries(b.domains).map(([name,v])=>`
     <div class="lesson-row">
      <b>${name}</b>
      <span>${v.score}점 ${
       a?"→ "+(a.domains[name]?.score??0)+"점":""
      }</span>
     </div>
    `).join("")}
   `}
  </section>

  <section class="card">
   <h2>학습 피드백</h2>
   ${b?this.feedback(b,a):"진단을 먼저 진행하세요."}
   <button class="btn primary" data-action="pre">
    역량 재진단
   </button>
  </section>`;
 },

 feedback(b,a){
  return Object.entries(b.domains)
   .sort((x,y)=>x[1].score-y[1].score)
   .map(([name,v])=>{
    const after=a?.domains[name]?.score;
    const gap=after===undefined?null:after-v.score;

    return `
    <div class="feedback">
     <b>${name}</b>
     <p>
      ${
       v.score<60
       ?"기초 개념부터 다시 학습하고 해당 영역의 실습을 반복하세요."
       :v.score<80
       ?"개념은 일부 이해했으나 실제 적용 연습이 더 필요합니다."
       :"기본 역량이 확인되었습니다. 심화 프로젝트를 수행하세요."
      }
     </p>
     ${
      gap===null?""
      :`<small>재평가 변화: ${gap>=0?"+":""}${gap}점</small>`
     }
    </div>`;
   }).join("");
 },

 init(){
  const b=State.before;
  const a=State.after;

  if(!b||!window.Chart)return;

  const labels=Object.keys(b.domains);

  const score=document.getElementById("scoreChart");
  const skill=document.getElementById("skillChart");

  if(score){
   App.charts.push(new Chart(score,{
    type:"bar",
    data:{
     labels:["전체 점수"],
     datasets:[
      {label:"Before",data:[b.total],backgroundColor:"#91a6b7"},
      {label:"After",data:[a?.total??0],backgroundColor:"#368c80"}
     ]
    },
    options:{
     indexAxis:"y",
     responsive:true,
     scales:{x:{min:0,max:100}},
     plugins:{legend:{position:"bottom"}}
    }
   }));
  }

  if(skill){
   App.charts.push(new Chart(skill,{
    type:"radar",
    data:{
     labels,
     datasets:[
      {
       label:"Before",
       data:labels.map(x=>b.domains[x].score),
       borderColor:"#91a6b7",
       backgroundColor:"rgba(145,166,183,.15)"
      },
      {
       label:"After",
       data:labels.map(x=>a?.domains[x]?.score??0),
       borderColor:"#368c80",
       backgroundColor:"rgba(54,140,128,.15)"
      }
     ]
    },
    options:{
     scales:{r:{min:0,max:100}},
     plugins:{legend:{position:"bottom"}}
    }
   }));
  }
 }
};
