
"use strict";

window.AssessmentView={
 question(){
  const i=State.question;
  const q=Quizzes[i];
  const answer=State.answers[i];
  const left=Assessment.remaining(i);

  return `
   <div class="between row">
    <span class="tag">${q.domain}</span>
    <span>${q.difficulty}</span>
   </div>

   <div class="timer-area">
    <div class="between row">
     <b>남은 시간</b>
     <strong id="timerText">${Math.ceil(left)}초</strong>
    </div>
    <div class="progress timer-progress">
     <span id="timerBar"
      style="width:${left/q.seconds*100}%"></span>
    </div>
   </div>

   <h2>Q${i+1}. ${App.escape(q.question)}</h2>

   <div class="options">
    ${q.options.map((v,n)=>`
     <button class="option ${
      answer===n?"selected":""
     }" data-action="answer" data-index="${n}"
      ${answer!==undefined?"disabled":""}>
      ${String.fromCharCode(65+n)}. ${App.escape(v)}
     </button>
    `).join("")}
   </div>

   <p class="muted">${
    answer===-1?"시간 초과":
    answer!==undefined?"답변 완료 · 수정 불가":
    "제한 시간 안에 답변하세요."
   }</p>`;
 },

 render(){
  const count=Object.keys(State.answers).length;

  return `
  <section class="card">
   <span class="tag">COMPETENCY TEST</span>
   <h1>AI 개발 역량 진단</h1>
   <div class="between row">
    <b id="examCount">${count}/${Quizzes.length}</b>
    <span>8개 영역</span>
   </div>
   <div class="progress">
    <span id="examBar"
     style="width:${count/Quizzes.length*100}%"></span>
   </div>
  </section>

  <section class="card">
   <div id="questionArea">${this.question()}</div>
   <div class="actions">
    <button class="btn outline" data-action="prev">이전</button>
    <button class="btn primary" data-action="next">다음</button>
   </div>
  </section>

  <section class="card">
   <h2>문제 목록</h2>
   <div id="questionGrid"
    class="ag-theme-quartz grid-area"></div>
   <button class="btn teal" data-action="finish">
    평가 제출
   </button>
  </section>`;
 }
};
