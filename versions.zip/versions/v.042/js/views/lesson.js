
"use strict";

window.LessonView={
 render(){
  const l=Lessons.find(x=>x.id===State.lesson);

  if(!l)return `<section class="card">단원을 찾을 수 없습니다.</section>`;

  return `
  <section class="card">
   <button class="btn outline" data-action="learning">
    ← 교육과정
   </button>

   <span class="tag">LESSON ${l.id}</span>
   <h1>${App.escape(l.title)}</h1>

   <h3>학습 목표</h3>
   <p>${App.escape(l.objective)}</p>

   <h3>핵심 개념</h3>
   ${l.concepts.map((x,i)=>`
    <div class="feedback">
     <b>개념 ${i+1}</b>
     <p>${App.escape(x)}</p>
    </div>
   `).join("")}

   <h3>코드 예제</h3>
   <pre><code>${App.escape(l.code)}</code></pre>

   <h3>실습</h3>
   <p>${App.escape(l.practice)}</p>

   <h3>응용 과제</h3>
   <p>${App.escape(l.challenge)}</p>

   <h3>이해도 확인</h3>
   <p>${App.escape(l.checkpoint)}</p>

   <textarea id="lessonNote"
    placeholder="실행 결과와 학습 기록을 작성하세요."
   >${App.escape(State.notes[l.id]??"")}</textarea>

   <button class="btn teal"
    data-action="lesson-complete" data-id="${l.id}">
    학습 완료 처리
   </button>
  </section>`;
 }
};
