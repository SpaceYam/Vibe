
"use strict";

window.Events={
 init(){
  document.addEventListener("click",e=>{
   const el=e.target.closest("[data-action]");
   if(!el)return;

   const a=el.dataset.action;
   const id=Number(el.dataset.id);
   const index=Number(el.dataset.index);

   switch(a){
    case "home":Router.go("home");break;
    case "learning":Router.go("learning");break;
    case "report":Router.go("report");break;
    case "prompt":Router.go("prompt");break;

    case "save-profile":{
     const get=id=>document.getElementById(id).value.trim();
     const name=get("pName");
     const project=get("pProject");

     if(!name||!project){
      App.toast("이름과 프로젝트 목표를 입력하세요.");
      break;
     }

     State.profile={
      name,project,
      goal:get("pGoal"),
      dev:get("pDev"),
      ai:get("pAI")
     };

     State.persist();
     Router.go("home");
     break;
    }

    case "pre":Assessment.start("diagnostic");break;
    case "final":
     App.modal("사후 평가","평가를 시작할까요?",
      ()=>Assessment.start("after"));
     break;

    case "lesson":Router.lesson(id);break;

    case "lesson-complete":
     Learning.complete(
      id,document.getElementById("lessonNote").value
     );
     break;

    case "answer":Assessment.answer(index);break;
    case "prev":Assessment.select(State.question-1);break;
    case "next":Assessment.select(State.question+1);break;

    case "finish":
     App.modal("평가 제출","미응답은 오답 처리됩니다.",
      ()=>Assessment.finish());
     break;

    case "generate-prompt":PromptLab.generate();break;
    case "copy-prompt":PromptLab.copy();break;
    case "confirm":{
     const fn=App.confirmAction;
     App.closeModal();
     fn?.();
     break;
    }
    case "cancel":App.closeModal();break;
   }
  });
 }
};
