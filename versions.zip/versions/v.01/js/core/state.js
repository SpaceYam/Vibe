
"use strict";
window.State={
page:"home",
course:null,
lesson:0,
mode:Store.get().mode||"beginner",
search:"",
quizIndex:0,
quizScore:0,
quizDone:false,
quizAnswers:{},
getMode(){return this.mode==="beginner"?"입문자":"기존 개발자"}
};
