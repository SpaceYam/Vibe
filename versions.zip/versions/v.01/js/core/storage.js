
"use strict";
window.Store={
key:"vibeSchool_v1",
get(){
try{return JSON.parse(localStorage.getItem(this.key))||{}}
catch{return {}}
},
set(data){
localStorage.setItem(this.key,JSON.stringify(data));
},
update(name,value){
const data=this.get();
data[name]=value;
this.set(data);
},
completed(){
return this.get().completed||[];
},
finish(id){
const list=this.completed();
if(!list.includes(id))list.push(id);
this.update("completed",list);
}
};
