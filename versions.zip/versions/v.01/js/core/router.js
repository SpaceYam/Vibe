
"use strict";
window.Router={
go(page,data={}){
Object.assign(State,data);
State.page=page;
App.render();
window.scrollTo(0,0);
},
home(){this.go("home")},
course(id){this.go("course",{course:id})},
lesson(id,index){this.go("lesson",{course:id,lesson:index})}
};
