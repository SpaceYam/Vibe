
"use strict";
window.Events={
init(){
const app=document.getElementById("app");
app.addEventListener("click",e=>{
const b=e.target.closest("[data-action]");
if(!b)return;
const a=b.dataset.action;
const id=b.dataset.id;
const index=Number(b.dataset.index);
switch(a){
case "home":Router.home();break;
case "start-learning":Router.course("ai");break;
case "mode-beginner":
State.mode="beginner";Store.update("mode",State.mode);App.render();break;
case "mode-developer":
State.mode="developer";Store.update("mode",State.mode);App.render();break;
case "course":Router.course(id);break;
case "lesson":Router.lesson(id,index);break;
case "prev-lesson":Router.lesson(id,Math.max(0,index-1));break;
case "next-lesson":Router.lesson(id,index+1);break;
case "complete":
Progress.mark(id,index);
Router.lesson(id,index);
break;
case "prompt":Router.go("prompt");break;
case "code":Router.go("code");break;
case "quiz":Quiz.start();break;
case "quiz-answer":Quiz.answer(index);break;
case "quiz-restart":Quiz.start();break;
case "glossary":Router.go("glossary");break;
case "projects":Router.go("projects");break;
case "build-prompt":
document.getElementById("prompt-output").textContent=Practice.build();break;
case "copy-prompt":Practice.copy();break;
case "run-code":Practice.run();break;
case "project":Practice.project(id);break;
}
});
app.addEventListener("input",e=>{
if(e.target.id==="glossary-search")GlossaryView.search(e.target.value);
});
}
};
