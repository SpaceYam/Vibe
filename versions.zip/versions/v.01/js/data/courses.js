
"use strict";
window.Courses=[
["ai","🧠","AI 원리 이해","인공지능과 LLM의 작동 원리",5],
["prompt","💬","AI 활용 기술","프롬프트와 AI 협업 능력",5],
["coding","💻","코딩 기초","웹 개발의 핵심 개념",6],
["vibe","⚡","바이브코딩","AI와 함께 개발하는 방법",5],
["design","📐","프로젝트 설계","아이디어부터 기능 명세까지",5],
["debug","🔧","디버깅과 관리","오류 해결과 코드 관리",5],
["deploy","🚀","서비스 배포","웹 서비스 공개와 운영",5],
["project","🏆","실전 프로젝트","배운 내용을 서비스로 구현",5]
].map(([id,icon,title,desc,count],i)=>({id,icon,title,desc,count,number:i+1}));
