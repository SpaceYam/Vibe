
"use strict";
window.ToolView={
prompt(){
return `<h1>프롬프트 실습실</h1><p class="muted">조건을 입력하면 구조화된 AI 요청문을 만들어 줍니다.</p>
<div class="card section">
<label>AI 역할</label><input id="p-role" value="시니어 웹 개발자">
<label>개발 목표</label><input id="p-goal" placeholder="예: 할 일 관리 웹사이트">
<label>사용자와 배경</label><input id="p-context" placeholder="예: 코딩을 처음 배우는 사람">
<label>기술 및 제약조건</label><textarea id="p-rules" placeholder="예: HTML CSS JS, 파일별 분리"></textarea>
<button class="btn section" data-action="build-prompt">프롬프트 생성</button>
<h3>생성 결과</h3><pre id="prompt-output">여기에 프롬프트가 생성됩니다.</pre>
<button class="btn secondary" data-action="copy-prompt">복사하기</button></div>`;
},
code(){
return `<h1>코드 학습실</h1><p class="muted">HTML 코드의 구조와 실행 결과를 확인해 보세요.</p>
<div class="card section"><label>HTML 코드</label>
<textarea id="code-input"><h1>안녕하세요!</h1>
<p>나의 첫 번째 웹페이지입니다.</p>
<button onclick="alert('성공!')">클릭하기</button></textarea>
<button class="btn section" data-action="run-code">실행하기</button>
<h3>실행 결과</h3><iframe id="code-result" sandbox="allow-scripts" style="width:100%;height:240px;background:white;border-radius:10px"></iframe></div>`;
},
quiz(){
return `<h1>AI 및 코딩 지식 퀴즈</h1><p class="muted">핵심 개념을 확인해 보세요.</p><div id="quiz-area"></div>`;
},
projects(){
return `<h1>실전 프로젝트</h1><p class="muted">배운 기술을 실제 결과물로 만들어 봅니다.</p><div class="grid section">${Projects.map(p=>`<div class="card"><span class="course-icon">${p.icon}</span><h3>${p.title}</h3><p>${p.desc}</p><p class="muted">주요 기능: ${p.features}</p><button class="btn secondary" data-action="project" data-id="${p.id}">제작 가이드</button></div>`).join("")}</div><div id="project-detail"></div>`;
},
glossary(){return GlossaryView.render()}
};
