
"use strict";
window.LessonView={
render(id,index){
const c=Courses.find(x=>x.id===id);
const l=Lessons[id]?.[index];
if(!l)return CourseView.render(id);
const beginner=State.mode==="beginner";
return `<div class="lesson-content">
<button class="btn ghost" data-action="course" data-id="${id}">← 과정 목록</button>
<p class="tag section">LESSON ${index+1} / ${Lessons[id].length}</p>
<h1>${l[0]}</h1>
<div class="card"><h3>📘 핵심 개념</h3><p>${l[1]}</p></div>
<div class="card section"><h3>🌱 ${beginner?"쉽게 이해하기":"기술적으로 이해하기"}</h3><p>${beginner?l[2]:l[3]}</p></div>
<div class="card section"><h3>💡 실전에서 기억할 점</h3><p>${l[3]}</p></div>
<div class="card section"><h3>✍️ 학습 확인</h3><p>이 개념을 자신의 말로 한 문장으로 설명해 보세요.</p><textarea id="lesson-note" placeholder="나의 학습 메모"></textarea></div>
<div class="section-title"><button class="btn secondary" data-action="prev-lesson" data-id="${id}" data-index="${index}">이전 강의</button>
<button class="btn" data-action="complete" data-id="${id}" data-index="${index}">${Progress.done(id,index)?"학습 완료됨":"학습 완료하기 →"}</button></div>
${index<Lessons[id].length-1?`<button class="btn secondary" data-action="next-lesson" data-id="${id}" data-index="${index}">다음 강의 →</button>`:""}
</div>`;
}
};
