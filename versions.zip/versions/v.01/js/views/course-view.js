
"use strict";
window.CourseView={
render(id){
const c=Courses.find(x=>x.id===id);
if(!c)return HomeView.render();
const lessons=Lessons[id];
return `<button class="btn ghost" data-action="home">← 홈으로</button>
<section class="section card">
<span class="course-icon">${c.icon}</span>
<span class="tag">COURSE ${c.number}</span>
<h1>${c.title}</h1><p class="muted">${c.desc}</p>
<div class="bar"><span style="width:${Progress.courseCount(id)/c.count*100}%"></span></div>
<p>${Progress.courseCount(id)} / ${lessons.length} 강의 완료</p>
</section>
<section class="section"><h2>강의 목록</h2>
${lessons.map((l,i)=>`<div class="card lesson-item" data-action="lesson" data-index="${i}" data-id="${id}"><div class="section-title"><strong>${i+1}. ${l[0]}</strong><span>${Progress.done(id,i)?"✅ 완료":"📖 학습하기"}</span></div><p class="muted">${l[1]}</p></div>`).join("")}
</section>`;
}
};
