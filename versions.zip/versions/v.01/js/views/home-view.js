
"use strict";
window.HomeView={
render(){
return `
<section class="hero">
<span class="tag">AI CODING ACADEMY</span>
<h1>상상하는 것을<br><span>직접 만드는 시대</span></h1>
<p class="muted">AI를 이해하고, 활용하고, 직접 서비스를 만들어 보세요.</p>
<button class="btn" data-action="start-learning">학습 시작하기 →</button>
</section>
<section class="section">
<div class="section-title"><h2>나의 학습 현황</h2><strong>${Progress.percent()}%</strong></div>
<div class="bar"><span style="width:${Progress.percent()}%"></span></div>
<p class="muted">${Progress.count()} / ${Progress.total()} 강의 완료</p>
</section>
<section class="section">
<div class="section-title"><h2>학습 경로 선택</h2></div>
<div class="two-grid">
<div class="card"><span class="course-icon">🌱</span><h3>처음 시작하는 입문자</h3><p class="muted">코딩 경험이 없어도 기초부터 배울 수 있습니다.</p><button class="btn" data-action="mode-beginner">입문자 경로</button></div>
<div class="card"><span class="course-icon">⚡</span><h3>기존 개발자</h3><p class="muted">기존 개발 지식을 바탕으로 AI 협업을 학습합니다.</p><button class="btn secondary" data-action="mode-developer">개발자 경로</button></div>
</div>
</section>
<section class="section">
<div class="section-title"><h2>전체 교육 과정</h2><span class="muted">8 COURSES</span></div>
<div class="grid">${Courses.map(c=>this.card(c)).join("")}</div>
</section>
<section class="section two-grid">
<div class="card"><h3>💬 프롬프트 실습실</h3><p class="muted">AI에게 제대로 지시하는 법을 연습합니다.</p><button class="btn secondary" data-action="prompt">실습하기</button></div>
<div class="card"><h3>🧠 지식 사전</h3><p class="muted">AI와 개발 용어를 쉽게 이해합니다.</p><button class="btn secondary" data-action="glossary">용어 배우기</button></div>
</section>`;
},
card(c){
return `<div class="card course-card" data-action="course" data-id="${c.id}"><span class="course-icon">${c.icon}</span><p class="tag">COURSE ${String(c.number).padStart(2,"0")}</p><h3>${c.title}</h3><p class="muted">${c.desc}</p><div class="bar"><span style="width:${Progress.courseCount(c.id)/c.count*100}%"></span></div><small class="muted">${Progress.courseCount(c.id)} / ${c.count} 강의</small></div>`;
}
};
