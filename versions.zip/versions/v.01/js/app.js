
"use strict";

window.App = {
  render() {
    let content = "";

    switch (State.page) {
      case "home":
        content = HomeView.render();
        break;

      case "course":
        content = CourseView.render(State.course);
        break;

      case "lesson":
        content = LessonView.render(State.course, State.lesson);
        break;

      case "prompt":
        content = ToolView.prompt();
        break;

      case "code":
        content = ToolView.code();
        break;

      case "quiz":
        content = Quiz.view();
        break;

      case "projects":
        content = ToolView.projects();
        break;

      case "glossary":
        content = ToolView.glossary();
        break;

      default:
        content = HomeView.render();
    }

    document.getElementById("app").innerHTML =
      this.shell(content);
  },

  shell(content) {
    return `
      <div class="shell">
        <header class="topbar">
          <a class="logo" href="#" data-action="home">
            VIBE<span>SCHOOL</span>
          </a>

          <nav class="nav">
            <button data-action="home">홈</button>
            <button data-action="projects">프로젝트</button>
            <button data-action="quiz">퀴즈</button>
            <button data-action="glossary">용어사전</button>
          </nav>
        </header>

        <main class="main">${content}</main>

        <footer class="footer">
          VIBE SCHOOL © 2026
          · LEARN AND BUILD WITH AI
        </footer>
      </div>`;
  },

  init() {
    Events.init();
    this.render();
  }
};

document.addEventListener("DOMContentLoaded", () => App.init());
