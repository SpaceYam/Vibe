
"use strict";
window.Practice={
build(){
const role=document.getElementById("p-role")?.value||"전문 개발자";
const goal=document.getElementById("p-goal")?.value||"웹사이트 만들기";
const context=document.getElementById("p-context")?.value||"초보 사용자";
const rules=document.getElementById("p-rules")?.value||"HTML CSS JavaScript 사용";
return `역할: ${role}\n목표: ${goal}\n사용자: ${context}\n제약조건: ${rules}\n\n작업을 작은 단계로 나누고, 각 단계의 결과와 테스트 방법을 설명해 주세요.`;
},
copy(){
const el=document.getElementById("prompt-output");
if(!el)return;
navigator.clipboard.writeText(el.textContent)
.then(()=>alert("프롬프트를 복사했습니다."))
.catch(()=>alert("복사할 수 없습니다. 직접 선택해 주세요."));
}
};
