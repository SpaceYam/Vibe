
"use strict";
window.Quiz={
start(){
State.quizIndex=0;
State.quizScore=0;
State.quizDone=false;
State.quizAnswers={};
Router.go("quiz");
},
answer(index){
if(State.quizDone||State.quizAnswers[State.quizIndex]!==undefined)return;
const q=Quizzes[State.quizIndex];
State.quizAnswers[State.quizIndex]=index;
if(index===q.correct)State.quizScore++;
State.quizIndex++;
if(State.quizIndex>=Quizzes.length)State.quizDone=true;
App.render();
},
reset(){this.start()}
};
