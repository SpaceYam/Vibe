
"use strict";

window.Practice = {
  build() {
    const val = id =>
      document.getElementById(id)?.value.trim() || "";

    const role = val("p-role") || "웹 개발 전문가";
    const goal = val("p-goal") || "웹사이트 제작";
    const context = val("p-context") || "초보 사용자";
    const rules = val("p-rules") || "HTML, CSS, JavaScript";

    return `# AI 바이브코딩 요청서

## 역할
${role}

## 개발 목표
${goal}

## 사용자
${context}

## 기술 및 제약조건
${rules}

## 작업 진행 순서
1. 요구사항 분석
2. 필요한 기능 목록 작성
3. 전체 파일 구조 설계
4. 각 파일의 코드 작성
5. 코드의 역할과 작동 원리 설명
6. 실행 및 테스트 방법 안내
7. 오류와 보안 문제 검토

## 추가 요청
- 초보자도 이해할 수 있도록 설명하세요.
- 코드를 작성할 때 파일명을 명시하세요.
- 한 번에 너무 많은 코드를 작성하지 마세요.
- 각 단계가 완료되면 검증 방법을 알려주세요.
- 불명확한 사항은 구현 전에 질문하세요.`;
  },

  copy() {
    const output = document.getElementById("prompt-output");
    if (!output?.textContent.trim()) {
      alert("먼저 프롬프트를 생성하세요.");
      return;
    }

    navigator.clipboard.writeText(output.textContent)
      .then(() => alert("프롬프트가 복사되었습니다."))
      .catch(() => alert("복사에 실패했습니다."));
  },

  run() {
    const input = document.getElementById("code-input");
    const frame = document.getElementById("code-result");

    if (!input || !frame) return;

    const code = input.value.trim();

    if (!code) {
      alert("실행할 코드를 입력하세요.");
      return;
    }

    frame.removeAttribute("src");
    frame.setAttribute("sandbox", "allow-scripts");
    frame.srcdoc = code;
  },

  project(id) {
    const p = Projects.find(x => x.id === Number(id));
    const detail = document.getElementById("project-detail");

    if (!p || !detail) return;

    const prompt = `당신은 전문 웹 개발자입니다.

프로젝트: ${p.title}
목표: ${p.desc}
필수 기능: ${p.features}

다음 순서로 개발하세요.
1. 요구사항 분석
2. 화면 설계
3. 파일 구조 작성
4. 기능별 코드 구현
5. 실행 방법 설명
6. 테스트 및 오류 수정

초보자도 이해할 수 있도록 단계별로 설명하세요.`;

    detail.innerHTML = `
      <div class="card section">
        <h2>${p.icon} ${p.title}</h2>
        <p>${p.desc}</p>
        <h3>필수 기능</h3>
        <p>${p.features}</p>
        <h3>AI 개발 프롬프트</h3>
        <pre id="project-prompt"></pre>
        <button class="btn" data-action="copy-project-prompt">
          프롬프트 복사
        </button>
      </div>`;

    document.getElementById("project-prompt").textContent = prompt;
  }
};
