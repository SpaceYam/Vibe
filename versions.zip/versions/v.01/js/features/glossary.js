
"use strict";
window.Glossary=[
["AI","데이터를 바탕으로 예측과 생성 등 지능적인 작업을 수행하는 기술"],
["LLM","대량의 텍스트로 학습한 대규모 언어 모델"],
["토큰","AI 모델이 텍스트를 처리하는 기본 단위"],
["프롬프트","AI에게 전달하는 지시와 입력 정보"],
["API","프로그램 사이에서 기능과 데이터를 주고받는 인터페이스"],
["HTML","웹페이지의 콘텐츠와 구조를 정의하는 언어"],
["CSS","웹페이지의 디자인과 배치를 담당하는 스타일 언어"],
["JavaScript","웹페이지의 동작과 로직을 구현하는 프로그래밍 언어"],
["DOM","HTML 문서를 객체 구조로 표현한 모델"],
["Git","코드 변경 이력을 관리하는 버전 관리 시스템"],
["디버깅","프로그램의 오류를 찾아 원인을 해결하는 과정"],
["리팩터링","기능을 유지하면서 코드 구조를 개선하는 작업"],
["배포","개발한 서비스를 사용자가 접근할 수 있게 공개하는 과정"],
["컨텍스트","AI가 응답을 생성할 때 참고하는 문맥과 정보"]
];
window.GlossaryView={
render(){
return `<h1>개발 용어 사전</h1><input id="glossary-search" placeholder="용어 검색"><div class="grid section" id="glossary-list">${this.items(Glossary)}</div>`;
},
items(data){
return data.map(([a,b])=>`<div class="card"><strong>${a}</strong><p class="muted">${b}</p></div>`).join("");
},
search(value){
document.getElementById("glossary-list").innerHTML=this.items(Glossary.filter(x=>(x[0]+x[1]).toLowerCase().includes(value.toLowerCase())));
}
};
