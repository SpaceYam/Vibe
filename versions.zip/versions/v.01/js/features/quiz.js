
"use strict";

window.Quiz = {
  start() {
    State.quizIndex = 0;
    State.quizScore = 0;
    State.quizDone = false;
    State.quizAnswers = {};
    Router.go("quiz");
  },

  answer(index) {
    const n = State.quizIndex;
    if (State.quizDone || State.quizAnswers[n] !== undefined) return;

    const q = Quizzes[n];
    if (!q || !q.a[index]) return;

    State.quizAnswers[n] = index;
    if (index === q.correct) State.quizScore++;

    App.render();
  },

  next() {
    if (State.quizAnswers[State.quizIndex] === undefined) return;

    if (State.quizIndex + 1 >= Quizzes.length) {
      State.quizDone = true;
    } else {
      State.quizIndex++;
    }

    App.render();
  },

  previous() {
    if (State.quizIndex > 0) {
      State.quizIndex--;
      App.render();
    }
  },

  view() {
    if (State.quizDone) {
      const score = State.quizScore;
      const total = Quizzes.length;
      const percent = Math.round(score / total * 100);

      return `
        <div class="card">
          <span class="tag">QUIZ RESULT</span>
          <h2>학습 결과</h2>
          <h1>${score} / ${total}점</h1>
          <h2>${percent}%</h2>
          <p>${percent >= 80
            ? "훌륭합니다! 내용을 잘 이해했습니다."
            : "조금 더 학습한 뒤 다시 도전해 보세요."}</p>
          <button class="btn" data-action="quiz-restart">
            다시 도전하기
          </button>
          <button class="btn secondary" data-action="home">
            홈으로
          </button>
        </div>`;
    }

    const n = State.quizIndex;
    const q = Quizzes[n];
    const selected = State.quizAnswers[n];
    const answered = selected !== undefined;
    const correct = selected === q.correct;

    return `
      <div class="card">
        <span class="tag">QUESTION ${n + 1} / ${Quizzes.length}</span>
        <div class="progress">
          <span style="width:${(n + 1) / Quizzes.length * 100}%"></span>
        </div>
        <h2>${q.q}</h2>

        <div class="answers">
          ${q.a.map((a, i) => `
            <button class="answer ${
              answered && i === q.correct ? "selected" : ""
            }" data-action="quiz-answer"
              data-index="${i}" ${answered ? "disabled" : ""}>
              ${String.fromCharCode(65 + i)}. ${a}
              ${answered && i === q.correct ? " ✓" : ""}
              ${answered && i === selected && !correct ? " ✕" : ""}
            </button>
          `).join("")}
        </div>

        ${answered ? `
          <div class="info-card">
            <strong>${correct ? "정답입니다!" : "아쉽습니다. 오답입니다."}</strong>
            <p>${q.why || "정답을 확인하고 관련 학습 내용을 복습해 보세요."}</p>
          </div>
        ` : ""}

        <div class="question-footer">
          <button class="btn secondary"
            data-action="quiz-prev" ${n === 0 ? "disabled" : ""}>
            이전 문제
          </button>
          <button class="btn" data-action="quiz-next"
            ${!answered ? "disabled" : ""}>
            ${n === Quizzes.length - 1 ? "결과 확인" : "다음 문제"}
          </button>
        </div>
      </div>`;
  }
};
