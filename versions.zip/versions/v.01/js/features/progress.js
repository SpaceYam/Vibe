
"use strict";
window.Progress={
id(course,index){return course+"-"+index},
done(course,index){return Store.completed().includes(this.id(course,index))},
mark(course,index){Store.finish(this.id(course,index))},
total(){
return Courses.reduce((n,c)=>n+c.count,0);
},
count(){return Store.completed().length},
percent(){return Math.round(this.count()/this.total()*100)},
courseCount(id){
return (Lessons[id]||[]).filter((_,i)=>this.done(id,i)).length;
}
};
