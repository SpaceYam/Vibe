
"use strict";

window.Profile = {
  render(){
    return `
      <div class="card">
        <h1>나의 학습 프로필</h1>
        <p>학습 목표를 설정하면 맞춤형 교육 경로를 설계합니다.</p>
        <label>이름</label>
        <input id="pName" placeholder="이름 또는 닉네임">
        <label>최종 학습 목표</label>
        <select id="pGoal">
          <option value="automation">업무 자동화</option>
          <option value="developer">Python 개발</option>
          <option value="service">AI 서비스 제작</option>
          <option value="data">데이터 분석</option>
          <option value="career">AI 개발자 취업</option>
        </select>
        <label>Python 경험</label>
        <select id="pLevel">
          <option value="beginner">처음 접함</option>
          <option value="basic">기초 문법 이해</option>
          <option value="intermediate">간단한 개발 가능</option>
          <option value="advanced">프로젝트 경험</option>
        </select>
        <label>하루 학습 가능 시간</label>
        <select id="pTime">
          <option value="30">30분</option>
          <option value="60">1시간</option>
          <option value="120">2시간</option>
          <option value="180">3시간 이상</option>
        </select>
        <label>만들고 싶은 프로젝트</label>
        <textarea id="pProject" placeholder="예: 업무용 AI 보고서 자동 생성 도구"></textarea>
        <button class="btn primary" data-action="save-profile">
          프로필 생성하기
        </button>
      </div>`;
  },

  save(){
    const name=document.getElementById("pName").value.trim();
    const project=document.getElementById("pProject").value.trim();
    if(!name||!project){
      App.toast("이름과 프로젝트 목표를 입력해 주세요.");
      return;
    }

    State.profile={
      name,
      goal:document.getElementById("pGoal").value,
      level:document.getElementById("pLevel").value,
      time:Number(document.getElementById("pTime").value),
      project
    };
    State.save();
    State.page="home";
    App.render();
    App.toast("학습 프로필이 생성되었습니다.");
  }
};
