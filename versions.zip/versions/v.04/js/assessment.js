
"use strict";

window.Exam = {
  grid:null,

  start(mode){
    if(mode==="after"&&!State.learningStarted){
      App.toast("학습을 먼저 완료해 주세요.");
      return;
    }
    State.resetExam(mode);
    State.page="assessment";
    App.render();
  },

  select(i){
    if(i<0||i>=DB.questions.length)return;
    State.current=i;
    App.updateQuestion();
  },

  answer(n){
    const i=State.current;
    if(State.answers[i]!==undefined)return;

    State.answers[i]=n;

    const node=this.grid?.getRowNode(String(i+1));
    node?.setDataValue("status","✓ 완료");

    App.updateQuestion();
    App.updateProgress();
    App.toast("답변이 저장되었습니다.");
  },

  score(){
    const domains={};
    let correct=0;
    DB.domains.forEach(d=>{
      const qs=DB.questions.filter(q=>q.domain===d);
      const hits=qs.filter(q=>
        State.answers[q.id-1]===q.answer
      ).length;
      domains[d]={
        score:Math.round(hits/qs.length*100),
        correct:hits,total:qs.length
      };
      correct+=hits;
    });
    return {
      total:Math.round(correct/DB.questions.length*100),
      domains, count:DB.questions.length
    };
  },

  finish(){
    if(Object.keys(State.answers).length!==DB.questions.length){
      App.toast("미완료 문제가 있습니다.");
      return;
    }

    const result=this.score();
    if(State.mode==="pre")State.before=result;
    else State.after=result;

    State.save();
    App.closeModal();

    State.page=State.mode==="pre"?"learning":"report";
    App.render();
    App.toast("평가가 완료되었습니다.");
  },

  render(){
    const done=Object.keys(State.answers).length;
    return `
      <div class="card">
        <h1>${State.mode==="pre"?"사전 역량 진단":"사후 역량 진단"}</h1>
        <div class="row between">
          <span id="examCount">${done}/25 완료</span>
          <span class="muted">총 25문항</span>
        </div>
        <div class="progress"><span id="examBar"
          style="width:${done/25*100}%"></span></div>
      </div>
      <div class="card">
        <div id="questionArea">${this.questionHTML()}</div>
        <div class="actions">
          <button class="btn outline" data-action="prev">이전</button>
          <button class="btn primary" data-action="next">다음</button>
        </div>
      </div>
      <div class="card">
        <h2>문제 목록</h2>
        <p class="muted">완료한 문항은 체크 표시되며 다시 수정할 수 없습니다.</p>
        <div id="questionGrid" class="ag-theme-quartz"></div>
        <button class="btn teal" data-action="finish">시험 제출</button>
      </div>`;
  },

  questionHTML(){
    const q=DB.questions[State.current];
    const answer=State.answers[q.id-1];
    const locked=answer!==undefined;

    return `
      <div class="question">
        <span class="tag">${q.domain} · ${q.type} · 난이도 ${q.difficulty}</span>
        <h2>Q${q.id}. ${q.title}</h2>
        <div class="options">
          ${q.options.map((v,i)=>`
            <button class="option ${answer===i?"selected":""}"
              data-action="answer" data-index="${i}"
              ${locked?"disabled":""}>
              ${String.fromCharCode(65+i)}. ${v}
              ${locked&&answer===i?" ✓":""}
            </button>`).join("")}
        </div>
        ${locked?`
          <p class="muted">답변 완료 · 읽기 전용</p>
        `:""}
      </div>`;
  },

  initGrid(){
    if(this.grid)return;

    this.grid=agGrid.createGrid(
      document.getElementById("questionGrid"),{
        getRowId:p=>String(p.data.no),
        rowData:DB.questions.map((q,i)=>({
          no:i+1,domain:q.domain,type:q.type,
          status:"미완료"
        })),
        columnDefs:[
          {field:"no",headerName:"번호",width:85},
          {field:"domain",headerName:"평가 영역",flex:1},
          {field:"type",headerName:"유형",width:100},
          {field:"status",headerName:"상태",width:110}
        ],
        defaultColDef:{sortable:true,resizable:true},
        onRowClicked:p=>this.select(p.data.no-1),
        suppressCellFocus:true
      }
    );

    Object.keys(State.answers).forEach(i=>{
      this.grid.getRowNode(String(Number(i)+1))
        ?.setDataValue("status","✓ 완료");
    });
  }
};
