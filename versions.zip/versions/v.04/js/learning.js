
"use strict";

window.Learning = {
  get completed(){
    return State.completed;
  },

  progress(){
    return Math.round(
      this.completed.length/DB.lessons.length*100
    );
  },

  recommended(){
    if(!State.before)return [];
    return Object.entries(State.before.domains)
      .filter(([,v])=>v.score<80)
      .sort((a,b)=>a[1].score-b[1].score)
      .map(([name])=>name);
  },

  render(){
    const weak=this.recommended();
    return `
      <div class="card">
        <h1>Python 학습 과정</h1>
        <p>진단 결과를 바탕으로 추천된 학습 단원을 확인하세요.</p>
        <div class="row between">
          <strong>전체 학습 진행도</strong>
          <strong>${this.progress()}%</strong>
        </div>
        <div class="progress">
          <span style="width:${this.progress()}%"></span>
        </div>
        <p class="muted">${this.completed.length}/${DB.lessons.length}개 단원 완료</p>
      </div>

      ${weak.length?`
        <div class="card recommended">
          <h2>우선 학습 추천</h2>
          <p>진단 결과에서 상대적으로 취약한 영역입니다.</p>
          ${weak.map(x=>`<span class="tag">${x}</span>`).join(" ")}
        </div>`:""}

      ${DB.lessons.map((l,i)=>{
        const finished=this.completed.includes(l.id);
        const priority=weak.includes(l.unit);
        return `
          <div class="card ${priority?"recommended":""}">
            <div class="row between">
              <span class="tag">${l.unit}</span>
              <span>${finished?"✓ 완료":priority?"우선 학습":"학습 전"}</span>
            </div>
            <h3>${l.title}</h3>
            <p class="muted">${l.objective}</p>
            <button class="btn primary"
              data-action="lesson" data-index="${i}">
              ${finished?"다시 보기":"학습하기"}
            </button>
          </div>`;
      }).join("")}

      <div class="card">
        <h2>학습 완료</h2>
        <button class="btn teal" data-action="learning-finish"
          ${this.progress()!==100?"disabled":""}>
          사후 진단 준비
        </button>
      </div>`;
  },

  detail(i){
    const l=DB.lessons[i];
    if(!l)return "";
    return `
      <div class="card">
        <button class="btn outline" data-action="learning">
          ← 학습 목록
        </button>
        <span class="tag">${l.unit}</span>
        <h1>${l.title}</h1>
        <h3>학습 목표</h3>
        <p>${l.objective}</p>
        <h3>핵심 개념</h3>
        <p>${l.theory}</p>
        <h3>코드 실습</h3>
        <pre><code>${App.escape(l.code)}</code></pre>
        <h3>실행 결과</h3>
        <pre>${App.escape(l.output)}</pre>
        <h3>따라 하기</h3>
        <p>${l.practice}</p>
        <h3>확인 문제</h3>
        <p>${l.task}</p>
        <textarea id="practiceAnswer"
          placeholder="직접 작성한 코드나 답변을 입력하세요."></textarea>
        <button class="btn teal" data-action="lesson-complete"
          data-index="${i}">
          학습 완료
        </button>
      </div>`;
  },

  complete(i){
    const l=DB.lessons[i];
    if(!State.completed.includes(l.id)){
      State.completed.push(l.id);
      State.save();
    }
    State.page="learning";
    App.render();
    App.toast("학습 진도가 저장되었습니다.");
  }
};
