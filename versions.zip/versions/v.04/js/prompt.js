
"use strict";

window.PromptBuilder = {
  render(){
    return `
      <div class="card">
        <span class="tag">PRACTICE TOOL</span>
        <h1>프롬프트 실습실</h1>
        <p>AI에게 전달할 명령을 직접 설계해 보세요.</p>

        <label>AI 역할</label>
        <input id="prRole" value="Python 전문 개발자">

        <label>개발 목표</label>
        <textarea id="prGoal" placeholder="예: CSV 파일을 분석하는 프로그램"></textarea>

        <label>사용 기술 및 인자</label>
        <input id="prTech" placeholder="예: Python, pandas">

        <label>제약 조건</label>
        <textarea id="prRules" placeholder="예: 함수 분리, 예외 처리, 주석 작성"></textarea>

        <label>출력 형식</label>
        <select id="prFormat">
          <option>전체 코드 + 설명 + 실행 예시</option>
          <option>단계별 구현 가이드</option>
          <option>JSON 형식</option>
          <option>코드 리뷰 및 개선안</option>
        </select>

        <button class="btn primary" data-action="generate-prompt">
          프롬프트 생성
        </button>
      </div>

      <div class="card">
        <h2>생성 결과</h2>
        <pre id="promptResult">입력값을 작성하고 생성 버튼을 눌러 주세요.</pre>
        <button class="btn teal" data-action="copy-prompt">
          결과 복사
        </button>
      </div>`;
  },

  generate(){
    const get=id=>document.getElementById(id).value.trim();
    const role=get("prRole");
    const goal=get("prGoal");
    const tech=get("prTech");
    const rules=get("prRules");
    const format=get("prFormat");

    if(!goal){
      App.toast("개발 목표를 입력해 주세요.");
      return;
    }

    const result=`
당신은 ${role}입니다.

[목표]
${goal}

[사용 기술]
${tech||"Python"}

[제약 조건]
${rules||"가독성과 유지보수성을 고려하세요."}

[작업 지침]
1. 요구사항을 분석하세요.
2. 구현 방법을 설명하세요.
3. 실행 가능한 코드를 작성하세요.
4. 오류 가능성을 검토하세요.
5. 테스트 예시를 제시하세요.

[출력 형식]
${format}

불명확한 요구사항이 있으면 먼저 질문하세요.
    `.trim();

    document.getElementById("promptResult").textContent=result;
    this.result=result;
  },

  copy(){
    if(!this.result){
      App.toast("먼저 프롬프트를 생성해 주세요.");
      return;
    }
    navigator.clipboard.writeText(this.result)
      .then(()=>App.toast("프롬프트를 복사했습니다."))
      .catch(()=>App.toast("클립보드 복사에 실패했습니다."));
  }
};
