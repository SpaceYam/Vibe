
"use strict";

window.State = {
  page:"home",
  profile:null,
  mode:"pre",
  current:0,
  answers:{},
  before:null,
  after:null,
  completed:[],
  learningStarted:false,

  init(){
    try{
      const s=JSON.parse(localStorage.getItem("vibe-school")||"{}");
      Object.assign(this,s);
    }catch(e){console.warn(e);}
  },

  save(){
    const keys=[
      "profile","before","after","completed","learningStarted"
    ];
    const data={};
    keys.forEach(k=>data[k]=this[k]);
    localStorage.setItem("vibe-school",JSON.stringify(data));
  },

  resetExam(mode){
    this.mode=mode;
    this.current=0;
    this.answers={};
  }
};
