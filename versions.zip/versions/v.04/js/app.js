
"use strict";

window.App = {
  chart:null,

  escape(s){
    return String(s).replace(/[&<>"']/g,c=>({
      "&":"&amp;","<":"&lt;",">":"&gt;",
      '"':"&quot;","'":"&#39;"
    })[c]);
  },

  toast(msg){
    const el=document.getElementById("toast");
    el.textContent=msg;
    el.classList.add("show");
    clearTimeout(this.timer);
    this.timer=setTimeout(()=>el.classList.remove("show"),2500);
  },

  modal(title,msg,fn){
    const el=document.getElementById("modal");
    el.innerHTML=`
      <div class="modal-box">
        <h2>${title}</h2><p>${msg}</p>
        <div class="actions">
          <button class="btn outline" data-action="cancel">취소</button>
          <button class="btn primary" data-action="confirm">확인</button>
        </div>
      </div>`;
    el.classList.add("show");
    this.confirm=fn;
  },

  closeModal(){
    document.getElementById("modal").classList.remove("show");
    this.confirm=null;
  },

  updateQuestion(){
    const el=document.getElementById("questionArea");
    if(el)el.innerHTML=Exam.questionHTML();
    this.updateProgress();
  },

  updateProgress(){
    const count=Object.keys(State.answers).length;
    const bar=document.getElementById("examBar");
    const label=document.getElementById("examCount");
    if(bar)bar.style.width=count/25*100+"%";
    if(label)label.textContent=count+"/25 완료";
  },

  render(){
    if(Exam.grid){
      Exam.grid.destroy();
      Exam.grid=null;
    }
    if(this.chart){
      this.chart.destroy();
      this.chart=null;
    }

    if(!State.profile){
      State.page="profile";
    }

    let content="";
    switch(State.page){
      case "profile":content=Profile.render();break;
      case "assessment":content=Exam.render();break;
      case "learning":content=Learning.render();break;
      case "lesson":content=Learning.detail(State.lessonIndex);break;
      case "prompt":content=PromptBuilder.render();break;
      case "report":content=this.report();break;
      default:content=this.home();
    }

    document.getElementById("app").innerHTML=`
      <header class="topbar">
        <div class="logo">VIBE<span>SCHOOL</span></div>
        <nav>
          <button data-action="home">홈</button>
          <button data-action="learning">학습</button>
          <button data-action="prompt">프롬프트 실습</button>
          <button data-action="report">학습 리포트</button>
        </nav>
      </header>
      <main>${content}</main>
      <footer>VIBE SCHOOL · PYTHON AI ACADEMY</footer>`;

    if(State.page==="assessment")Exam.initGrid();
    if(State.page==="report")this.initReport();
  },

  home(){
    return `
      <div class="card">
        <span class="tag">PYTHON AI ACADEMY</span>
        <h1>안녕하세요, ${this.escape(State.profile?.name||"학습자")}님.</h1>
        <h2>당신의 목표: ${this.escape(State.profile?.project||"")}</h2>
        <p>학습 목표를 향한 성장을 시작하세요.</p>
        <div class="progress">
          <span style="width:${Learning.progress()}%"></span>
        </div>
        <p>전체 학습 진도 ${Learning.progress()}%</p>
        <div class="grid">
          <div class="stat"><strong>${State.before?State.before.total+"점":"-"}</strong>사전 평가</div>
          <div class="stat"><strong>${Learning.progress()}%</strong>학습 진도</div>
          <div class="stat"><strong>${State.after?State.after.total+"점":"-"}</strong>사후 평가</div>
        </div>
      </div>
      <div class="card">
        <h2>나의 학습 과정</h2>
        <button class="btn primary" data-action="pre"
          ${State.before?"disabled":""}>역량 진단</button>
        <button class="btn teal" data-action="learning">학습하기</button>
        <button class="btn outline" data-action="prompt">프롬프트 실습</button>
        <button class="btn outline" data-action="report">학습 리포트</button>
      </div>`;
  },

  report(){
    if(!State.before||!State.after)
      return `<div class="card"><h2>사전·사후 평가 완료 후 리포트를 확인할 수 있습니다.</h2></div>`;

    const b=State.before,a=State.after;
    const diff=a.total-b.total;
    const weak=Object.entries(a.domains)
      .sort((x,y)=>x[1].score-y[1].score);

    const feedback=weak.map(([d,v])=>{
      const old=b.domains[d].score;
      if(v.score<60)
        return `${d}: 사후 정답률이 ${v.score}%입니다. 기본 개념부터 복습하고 관련 단원의 실습을 다시 수행하세요.`;
      if(v.score<80)
        return `${d}: ${v.score}%로 추가 연습이 필요합니다. 응용 문제와 코드 작성 연습을 권장합니다.`;
      if(v.score>old)
        return `${d}: ${old}%에서 ${v.score}%로 향상되었습니다. 현재 수준을 유지하면서 실제 프로젝트에 적용해 보세요.`;
      return `${d}: ${v.score}%입니다. 이해한 내용을 직접 구현하고 설명하는 연습을 권장합니다.`;
    });

    return `
      <div class="card">
        <h1>통합 학습 리포트</h1>
        <div class="grid">
          <div class="stat"><strong>${b.total}점</strong>BEFORE</div>
          <div class="stat"><strong>${a.total}점</strong>AFTER</div>
          <div class="stat"><strong>${diff>0?"+":""}${diff}점</strong>성장 점수</div>
        </div>
        <h2>역량별 점수 비교</h2>
        <div class="chart-box"><canvas id="reportChart"></canvas></div>
      </div>
      <div class="card">
        <h2>학습 결과 피드백</h2>
        ${feedback.map(x=>`<p>• ${x}</p>`).join("")}
      </div>
      <div class="card">
        <h2>평가 해석 및 유의사항</h2>
        <p>평가 문항 ${a.count}개, 영역별 5문항으로 측정했습니다.</p>
        <p class="muted">소수의 객관식 문항만으로 실제 개발 능력을 확정할 수 없습니다. 프로젝트 수행, 코드 품질, 디버깅 평가를 추가해야 합니다.</p>
      </div>`;
  },

  initReport(){
    const b=State.before,a=State.after;
    if(!b||!a)return;
    const labels=DB.domains;
    this.chart=new Chart(document.getElementById("reportChart"),{
      type:"bar",
      data:{
        labels,
        datasets:[
          {label:"Before",data:labels.map(d=>b.domains[d].score),
           backgroundColor:"#aebbc9",grouped:false,barThickness:16},
          {label:"After",data:labels.map(d=>a.domains[d].score),
           backgroundColor:"#398b82",grouped:false,barThickness:8}
        ]
      },
      options:{
        indexAxis:"y",responsive:true,maintainAspectRatio:false,
        scales:{x:{min:0,max:100}},
        plugins:{legend:{position:"bottom"}}
      }
    });
  },

  init(){
    State.init();
    document.addEventListener("click",e=>{
      const el=e.target.closest("[data-action]");
      if(!el)return;
      const action=el.dataset.action;
      const index=Number(el.dataset.index);

      switch(action){
        case "save-profile":Profile.save();break;
        case "home":State.page="home";this.render();break;
        case "pre":Exam.start("pre");break;
        case "after":Exam.start("after");break;
        case "learning":State.page="learning";this.render();break;
        case "prompt":State.page="prompt";this.render();break;
        case "report":State.page="report";this.render();break;
        case "answer":Exam.answer(index);break;
        case "prev":Exam.select(State.current-1);break;
        case "next":Exam.select(State.current+1);break;
        case "lesson":
          State.lessonIndex=index;
          State.page="lesson";this.render();break;
        case "lesson-complete":
          Learning.complete(index);break;
        case "learning-finish":
          this.modal("학습 완료","사후 평가를 시작할까요?",()=>{
            State.learningStarted=true;
            State.save();
            this.closeModal();
            Exam.start("after");
          });break;
        case "finish":
          this.modal("시험 제출","답변을 제출하면 수정할 수 없습니다.",()=>Exam.finish());break;
        case "generate-prompt":PromptBuilder.generate();break;
        case "copy-prompt":PromptBuilder.copy();break;
        case "confirm":this.confirm?.();break;
        case "cancel":this.closeModal();break;
      }
    });
    this.render();
  }
};

document.addEventListener("DOMContentLoaded",()=>App.init());
