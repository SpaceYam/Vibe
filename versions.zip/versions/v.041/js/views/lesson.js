
"use strict";

window.LessonView = {
  render() {
    const l = Lessons.find(x => x.id === State.lesson);

    if (!l) {
      return `<section class="card">단원을 찾을 수 없습니다.</section>`;
    }

    const done = Progress.done(l.id);

    // 문자열과 배열 모두 지원
    const theory = Array.isArray(l.theory)
      ? l.theory
      : l.theory
        ? [l.theory]
        : [];

    return `
      <section class="card">
        <button class="btn outline" data-action="learning">
          ← 교육과정
        </button>

        <span class="tag">
          ${App.escape(Courses[l.courseId - 1]?.title ?? "학습")}
        </span>

        <h1>${App.escape(l.title)}</h1>

        <h3>학습 목표</h3>
        <p>${App.escape(l.objective ?? "")}</p>

        <h3>핵심 이론</h3>
        ${theory.map(t => `
          <p>${App.escape(t)}</p>
        `).join("")}

        <h3>코드 예제</h3>
        <pre><code>${App.escape(l.code ?? "")}</code></pre>

        <h3>실습</h3>
        <p>${App.escape(l.practice ?? "")}</p>

        <h3>학습 확인 과제</h3>
        <p>${App.escape(l.task ?? "")}</p>

        <label>실습 결과 및 학습 기록</label>

        <textarea
          id="lessonNote"
          placeholder="직접 수행한 실습과 결과를 기록하세요."
        >${App.escape(State.notes[l.id] ?? "")}</textarea>

        <button
          class="btn teal"
          data-action="lesson-complete"
          data-id="${l.id}"
        >
          ${done ? "학습 기록 업데이트" : "학습 완료 처리"}
        </button>
      </section>
    `;
  }
};
