
"use strict";

window.AssessmentView={
  question(){
    const i=State.question;
    const q=Quizzes[i];
    const answer=State.answers[i];
    const confidence=State.confidence[i];

    return `
      <span class="tag">${q.domain}</span>
      <h2>Q${i+1}. ${q.question}</h2>
      <div class="options">
        ${q.options.map((v,n)=>`
          <button class="option ${answer===n?"selected":""}"
            data-action="answer" data-index="${n}"
            ${answer!==undefined?"disabled":""}>
            ${String.fromCharCode(65+n)}. ${v}
            ${answer===n?" ✓":""}
          </button>`).join("")}
      </div>

      <div class="confidence">
        <b>답변 확신도</b>
        <p class="muted">정답 여부와 별개로 자신의 확신 수준을 기록하세요.</p>
        <div class="row">
          ${["전혀 확신 없음","조금 확신","매우 확신"].map((v,n)=>`
            <button class="btn ${confidence===n?"teal":"outline"}"
              data-action="confidence" data-value="${n}"
              ${answer===undefined?"disabled":""}>${v}</button>
          `).join("")}
        </div>
      </div>
      ${answer!==undefined?'<p class="muted">✓ 답변 완료 · 수정 불가</p>':""}`;
  },

  render(){
    const count=Object.keys(State.answers).length;
    return `
      <section class="card">
        <span class="tag">COMPETENCY ASSESSMENT</span>
        <h1>${State.examMode==="pre"?"사전 역량 진단":"사후 역량 진단"}</h1>
        <div class="between row">
          <b id="examCount">${count}/${Quizzes.length} 완료</b>
          <span>8개 영역 · ${Quizzes.length}문항</span>
        </div>
        <div class="progress">
          <span id="examBar" style="width:${count/Quizzes.length*100}%"></span>
        </div>
      </section>

      <section class="card">
        <div id="questionArea">${this.question()}</div>
        <div class="actions">
          <button class="btn outline" data-action="prev">이전</button>
          <button class="btn primary" data-action="next">다음</button>
        </div>
      </section>

      <section class="card">
        <h2>문제 목록</h2>
        <p class="muted">완료된 문항은 읽기 전용입니다. 번호를 클릭하면 해당 문제로 이동합니다.</p>
        <div id="questionGrid" class="ag-theme-quartz"></div>
        <button class="btn teal" data-action="finish">평가 제출</button>
      </section>`;
  }
};
