
"use strict";

window.ReportView={
  render(){
    const b=State.before,a=State.after;
    if(!b||!a){
      return `
        <section class="card">
          <h1>학습 리포트</h1>
          <p>사전 평가와 사후 평가를 모두 완료하면 성장 리포트가 생성됩니다.</p>
          <button class="btn teal" data-action="home">홈으로 이동</button>
        </section>`;
    }

    const labels=Courses.map(c=>c.title);
    const feedback=Courses.map(c=>{
      const x=b.domains[c.title];
      const y=a.domains[c.title];
      const delta=y.score-x.score;
      let msg;

      if(y.score<60)msg="기초 개념부터 다시 학습하고 기본 실습을 반복하세요.";
      else if(y.score<80)msg="응용 문제와 직접 구현하는 프로젝트를 추가하세요.";
      else if(delta>0)msg="성장한 영역입니다. 실제 서비스에 적용해 보세요.";
      else msg="현재 역량을 유지하고 더 복잡한 문제에 도전하세요.";

      return `<div class="feedback">
        <b>${c.title} · ${y.score}점 (${delta>0?"+":""}${delta})</b>
        <p>${msg}</p>
        <small>정답 ${y.correct}/${y.total} · 확신 응답 ${y.confident}/${y.total}</small>
      </div>`;
    }).join("");

    return `
      <section class="card">
        <span class="tag">LEARNING REPORT</span>
        <h1>통합 학습 성장 리포트</h1>
        <div class="grid">
          <div class="stat"><strong>${b.total}</strong>BEFORE</div>
          <div class="stat"><strong>${a.total}</strong>AFTER</div>
          <div class="stat"><strong>${a.total-b.total>0?"+":""}${a.total-b.total}</strong>변화 점수</div>
        </div>

        <h2>영역별 점수 비교</h2>
        <p class="muted">Before는 배경 막대, After는 앞쪽 막대로 표현합니다.</p>
        <div class="chart-box"><canvas id="barChart"></canvas></div>

        <h2>기술 역량 비교</h2>
        <div class="chart-box radar"><canvas id="radarChart"></canvas></div>
      </section>

      <section class="card">
        <h2>학습 피드백 및 개선 방향</h2>
        ${feedback}
      </section>

      <section class="card">
        <h2>평가 신뢰도 안내</h2>
        <p>현재 점수는 24개 객관식 문항을 기반으로 한 학습 진단 지표입니다. 각 영역당 3문항이므로 실제 개발 능력을 확정하는 점수는 아닙니다.</p>
        <p>정답률과 응답 확신도는 별도로 해석해야 합니다. 높은 확신도로 틀린 문항은 오개념 가능성이 있으므로 우선 복습 대상으로 삼습니다.</p>
        <p>실제 개발 역량을 확인하려면 코드 작성, 실행, 디버깅, 테스트 통과 및 프로젝트 완성도를 추가 평가해야 합니다.</p>
      </section>`;
  },

  init(){
    const b=State.before,a=State.after;
    if(!b||!a)return;

    const labels=Courses.map(c=>c.title);
    const before=labels.map(x=>b.domains[x].score);
    const after=labels.map(x=>a.domains[x].score);

    App.charts=[
      new Chart(document.getElementById("barChart"),{
        type:"bar",
        data:{labels,datasets:[
          {
            label:"Before",data:before,
            backgroundColor:"#b7c4d1",
            grouped:false,barThickness:20
          },
          {
            label:"After",data:after,
            backgroundColor:"#398b82",
            grouped:false,barThickness:10
          }
        ]},
        options:{
          indexAxis:"y",responsive:true,
          maintainAspectRatio:false,
          scales:{x:{min:0,max:100}},
          plugins:{legend:{position:"bottom"}}
        }
      }),
      new Chart(document.getElementById("radarChart"),{
        type:"radar",
        data:{labels,datasets:[
          {
            label:"Before",data:before,
            borderColor:"#aab9ca",
            backgroundColor:"#aab9ca33"
          },
          {
            label:"After",data:after,
            borderColor:"#398b82",
            backgroundColor:"#398b8233"
          }
        ]},
        options:{
          responsive:true,maintainAspectRatio:false,
          scales:{r:{min:0,max:100,ticks:{stepSize:20}}
          }
        }
      })
    ];
  }
};
