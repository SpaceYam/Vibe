
"use strict";

window.HomeView={
  profile(){
    return `
      <section class="card profile">
        <span class="tag">WELCOME TO VIBE SCHOOL</span>
        <h1>나만의 AI 개발 학습 경로 만들기</h1>
        <p>목표와 경험을 바탕으로 학습 계획을 설정합니다.</p>

        <label>이름 또는 닉네임</label>
        <input id="pName" placeholder="이름">

        <label>최종 학습 목표</label>
        <select id="pGoal">
          <option>AI 서비스를 직접 개발하고 싶다</option>
          <option>AI 개발자로 취업하고 싶다</option>
          <option>업무 자동화 시스템을 만들고 싶다</option>
          <option>AI Agent를 만들고 싶다</option>
          <option>AI 기술을 사업에 활용하고 싶다</option>
        </select>

        <label>개발 경험</label>
        <select id="pDev">
          <option>개발 경험 없음</option>
          <option>기초 문법 학습 경험</option>
          <option>개인 프로젝트 경험</option>
          <option>실무 개발 경험</option>
        </select>

        <label>AI 활용 경험</label>
        <select id="pAI">
          <option>AI를 거의 사용하지 않음</option>
          <option>ChatGPT 등 기본 사용</option>
          <option>프롬프트 설계 경험</option>
          <option>AI API 사용 경험</option>
          <option>AI 서비스 개발 경험</option>
        </select>

        <label>학습 가능 시간</label>
        <select id="pTime">
          <option>하루 30분</option>
          <option>하루 1시간</option>
          <option>하루 2시간</option>
          <option>하루 3시간 이상</option>
        </select>

        <label>만들고 싶은 최종 프로젝트</label>
        <textarea id="pProject" placeholder="예: 문서를 분석하는 AI Agent"></textarea>

        <button class="btn primary" data-action="save-profile">
          프로필 생성 및 시작
        </button>
      </section>`;
  },

  render(){
    const p=State.profile;
    if(!p)return this.profile();
    return `
      <section class="hero">
        <span class="tag">AI VIBE DEVELOPER ACADEMY</span>
        <h1>AI를 이해하고, AI와 함께 개발하세요.</h1>
        <p>이론부터 실전 프로젝트까지, 개발 역량을 완성합니다.</p>
      </section>

      <section class="card">
        <h2>안녕하세요, ${App.escape(p.name)}님.</h2>
        <p>목표: ${App.escape(p.goal)}</p>
        <p>최종 프로젝트: ${App.escape(p.project)}</p>
        <div class="between row">
          <b>학습 진행도</b><b>${Progress.percent()}%</b>
        </div>
        <div class="progress">
          <span style="width:${Progress.percent()}%"></span>
        </div>
        <div class="grid">
          <div class="stat"><strong>${State.before?.total??"-"}</strong>사전 평가</div>
          <div class="stat"><strong>${Progress.percent()}%</strong>학습 진도</div>
          <div class="stat"><strong>${State.after?.total??"-"}</strong>사후 평가</div>
        </div>
      </section>

      <section class="card">
        <h2>학습 메뉴</h2>
        <div class="actions">
          <button class="btn primary" data-action="pre"
            ${State.before?"disabled":""}>역량 진단</button>
          <button class="btn teal" data-action="learning">교육과정</button>
          <button class="btn outline" data-action="prompt">프롬프트 실습</button>
          <button class="btn outline" data-action="report">학습 리포트</button>
        </div>
      </section>

      <section class="card">
        <h2>8개 핵심 교육 영역</h2>
        <div class="grid">
          ${Courses.map((c,i)=>`
            <div class="stat">
              <strong>0${i+1}</strong>${c.title}
              <small>${c.lessons.length}개 단원</small>
            </div>`).join("")}
        </div>
      </section>`;
  }
};
