
"use strict";

window.State={
  page:"home",
  profile:null,
  completed:[],
  notes:{},
  before:null,
  after:null,
  answers:{},
  confidence:{},
  examMode:"pre",
  question:0,
  lesson:1,

  init(){
    const saved=Store.load();
    Object.assign(this,saved);
  },

  persist(){
    Store.save({
      profile:this.profile,
      completed:this.completed,
      notes:this.notes,
      before:this.before,
      after:this.after
    });
  },

  resetExam(mode){
    this.examMode=mode;
    this.answers={};
    this.confidence={};
    this.question=0;
  }
};
