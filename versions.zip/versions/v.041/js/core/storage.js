
"use strict";

window.Store={
  key:"vibe-school-v1",
  load(){
    try{
      return JSON.parse(localStorage.getItem(this.key))||{};
    }catch(e){return {};}
  },
  save(data){
    localStorage.setItem(this.key,JSON.stringify(data));
  },
  clear(){
    localStorage.removeItem(this.key);
  }
};
