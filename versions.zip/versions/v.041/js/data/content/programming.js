
"use strict";

window.LessonContent = window.LessonContent || {};
LessonContent.programming = [
{
concepts:[
"Python은 간결한 문법과 풍부한 라이브러리를 갖춘 범용 언어다. 변수, 자료형, 조건문, 반복문, 함수와 예외 처리를 익힌다.",
"리스트는 순서가 있는 컬렉션이고 딕셔너리는 키와 값으로 데이터를 관리한다. AI 애플리케이션에서는 JSON과 함께 자주 사용된다.",
"함수는 입력을 받아 처리하고 결과를 반환한다. 재사용 가능한 작은 단위로 나누는 습관이 중요하다."
],
example:`def summarize(values):
    if not values:
        return 0
    return sum(values) / len(values)

scores = [80, 90, 75]
print(summarize(scores))`,
practice:"사용자 입력을 받아 점수 평균, 최댓값, 최솟값을 계산하는 프로그램을 작성한다.",
challenge:"입력 검증과 예외 처리를 추가해 잘못된 데이터에도 안전하게 동작하도록 만든다.",
checkpoint:"함수의 반환값과 화면 출력의 차이는?"
},
{
concepts:[
"JavaScript는 브라우저와 서버 환경에서 사용하는 언어다. 변수, 객체, 배열, 함수와 모듈을 이해해야 한다.",
"Promise는 비동기 작업의 완료 또는 실패를 표현한다. async/await는 비동기 코드를 읽기 쉽게 작성하도록 돕는다.",
"DOM은 웹 문서의 구조를 객체로 표현한다. 이벤트 리스너로 사용자 입력과 화면 변화를 연결할 수 있다."
],
example:`async function loadData() {
  try {
    const response = await fetch("/api/data");
    if (!response.ok) throw new Error("요청 실패");
    return await response.json();
  } catch (error) {
    console.error(error);
  }
}`,
practice:"버튼 클릭 시 API를 요청하고 로딩, 성공, 오류 상태를 각각 화면에 표현한다.",
challenge:"비동기 요청이 여러 번 발생할 때 중복 요청을 방지하는 방법을 구현한다.",
checkpoint:"await가 없을 때와 있을 때의 실행 흐름 차이는?"
},
{
concepts:[
"자료구조는 데이터를 저장하고 접근하는 방식이다. 배열, 연결 리스트, 스택, 큐, 해시 테이블과 트리를 이해한다.",
"알고리즘 복잡도는 입력 크기에 따른 연산량의 증가를 설명한다. Big O 표기법으로 대표적인 시간 복잡도를 비교한다.",
"AI 서비스에서도 검색, 캐싱, 중복 제거와 데이터 처리 과정에 자료구조가 중요하다."
],
example:`from collections import deque

queue = deque()
queue.append("task-1")
queue.append("task-2")

print(queue.popleft())`,
practice:"작업 대기열을 큐로 구현하고 FIFO 동작을 확인한다.",
challenge:"같은 검색 기능을 리스트와 딕셔너리로 구현하고 성능 차이를 비교한다.",
checkpoint:"해시 테이블이 검색에 유리한 이유는?"
},
{
concepts:[
"HTML은 콘텐츠의 의미와 구조를 정의하고 CSS는 시각적 표현을 담당한다. JavaScript는 동작과 상호작용을 구현한다.",
"시맨틱 HTML은 header, nav, main, section, article 등 요소의 의미를 명확하게 표현한다.",
"반응형 디자인은 화면 크기에 따라 레이아웃을 조정한다. Flexbox, Grid와 미디어 쿼리를 활용한다."
],
example:`<main>
  <section>
    <h1>AI Assistant</h1>
    <input id="question">
    <button id="send">질문하기</button>
    <div id="result"></div>
  </section>
</main>`,
practice:"질문 입력, 전송 버튼, 응답 표시 영역으로 구성된 AI 챗봇 화면을 만든다.",
challenge:"모바일과 데스크톱에서 모두 사용 가능한 반응형 UI를 완성한다.",
checkpoint:"시맨틱 HTML이 접근성과 유지보수에 중요한 이유는?"
},
{
concepts:[
"HTTP는 클라이언트와 서버가 데이터를 교환하는 규약이다. GET, POST, PUT, PATCH, DELETE의 의미를 구분한다.",
"REST API는 리소스를 중심으로 인터페이스를 설계한다. 상태 코드와 JSON 응답 구조를 일관되게 유지해야 한다.",
"Git은 버전 관리 도구다. commit, branch, merge, pull request를 통해 변경 이력을 관리한다."
],
example:`fetch("/api/tasks", {
  method: "POST",
  headers: {"Content-Type":"application/json"},
  body: JSON.stringify({title:"Learn AI"})
}).then(r => r.json())
  .then(data => console.log(data));`,
practice:"간단한 할 일 API를 설계하고 요청과 응답 JSON을 정의한다.",
challenge:"잘못된 요청, 인증 실패, 서버 오류의 응답 규격을 설계한다.",
checkpoint:"HTTP 401과 403의 차이는?"
}
];
