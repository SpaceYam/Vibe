
"use strict";

window.LessonContent = window.LessonContent || {};
LessonContent.ai = [
{
concepts:[
"인공지능은 인간의 인지적 작업을 기계가 수행하도록 만드는 기술 분야다. 규칙 기반 시스템과 데이터 기반 학습 시스템은 접근 방식이 다르다.",
"머신러닝은 입력 데이터와 정답 또는 보상으로부터 패턴을 학습한다. 지도학습, 비지도학습, 강화학습의 차이를 이해해야 한다.",
"딥러닝은 여러 층의 신경망으로 특징을 학습한다. 학습 데이터, 손실 함수, 역전파, 경사하강법이 기본 구성이다.",
"생성형 AI는 학습한 데이터의 구조와 패턴을 이용해 새로운 콘텐츠를 생성한다. 확률적으로 생성하므로 환각과 편향이 발생할 수 있다."
],
example:`# 지도학습 간단 예제
from sklearn.linear_model import LinearRegression

X = [[1], [2], [3], [4]]
y = [2, 4, 6, 8]

model = LinearRegression()
model.fit(X, y)

print(model.predict([[5]]))
# 약 10`,
practice:"학습 데이터와 테스트 데이터를 분리하고 간단한 예측 모델을 만들어 보자. 학습 데이터에만 높은 성능이 나오는 경우도 관찰한다.",
challenge:"분류와 회귀 문제를 각각 정의하고 어떤 문제에 어떤 모델을 사용할지 근거를 작성한다.",
checkpoint:"학습 데이터와 테스트 데이터를 분리해야 하는 이유는 무엇인가?"
},
{
concepts:[
"AI는 입력, 모델, 출력의 구조로 이해할 수 있다. 실제 서비스에서는 데이터 수집, 전처리, 추론, 후처리까지 연결된다.",
"지도학습은 정답 레이블을 이용하고 비지도학습은 데이터의 구조를 발견한다. 강화학습은 행동에 대한 보상을 기반으로 정책을 학습한다.",
"과적합은 학습 데이터에 지나치게 맞춰져 새로운 데이터에서 성능이 떨어지는 현상이다. 데이터 분리와 정규화, 검증으로 관리한다."
],
example:`from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
model.fit(X_train, y_train)
print(model.score(X_test, y_test))`,
practice:"훈련과 테스트 정확도를 비교하고 과적합 여부를 설명한다.",
challenge:"데이터가 부족한 상황에서 과적합을 줄이는 방법 세 가지를 조사한다.",
checkpoint:"테스트 데이터를 학습에 사용하면 어떤 문제가 발생하는가?"
},
{
concepts:[
"생성형 AI는 다음 토큰의 확률 분포를 기반으로 문장을 생성하는 언어 모델을 포함한다.",
"Temperature는 출력 확률 분포의 분산을 조절한다. 값이 높으면 다양한 표현이 가능하지만 결과의 일관성이 낮아질 수 있다.",
"생성형 AI는 그럴듯한 문장을 만들 수 있지만 사실 검증을 보장하지 않는다. 출처 확인과 외부 데이터 검증이 중요하다."
],
example:`# 생성 결과를 평가하는 기준
criteria = [
    "사실 정확성",
    "요구사항 충족",
    "출처와 근거",
    "일관성",
    "안전성"
]
for item in criteria:
    print(item)`,
practice:"동일한 질문을 여러 번 입력하고 결과의 일관성과 사실성을 비교한다.",
challenge:"AI가 잘못된 정보를 생성하는 상황을 세 가지 찾아 검증 절차를 설계한다.",
checkpoint:"언어 모델의 유창함이 사실의 정확성을 의미하지 않는 이유는?"
},
{
concepts:[
"LLM은 대규모 텍스트 데이터를 이용해 언어의 통계적 패턴과 문맥 관계를 학습한다.",
"모델의 파라미터는 학습된 정보를 수치로 표현한다. 파라미터 수가 많다고 모든 작업에서 우수한 것은 아니다.",
"모델 성능은 학습 데이터, 아키텍처, 학습 방법, 추론 설정과 평가 기준의 영향을 받는다."
],
example:`model_info = {
    "architecture": "Transformer",
    "task": "Next Token Prediction",
    "input": "Token Sequence",
    "output": "Probability Distribution"
}
print(model_info)`,
practice:"서로 다른 LLM을 동일한 질문으로 비교하고 응답 품질과 비용을 기록한다.",
challenge:"모델 선택 시 정확도, 비용, 속도, 데이터 보안의 우선순위를 정한다.",
checkpoint:"파라미터 수만으로 모델을 평가하기 어려운 이유는?"
},
{
concepts:[
"AI 시스템은 개인정보, 저작권, 편향과 허위정보 문제를 고려해야 한다.",
"민감한 정보를 외부 모델에 전달하지 않도록 데이터 최소화와 접근 통제를 적용한다.",
"AI의 출력은 사람이 검토할 수 있어야 하며 중요한 의사결정에는 검증 가능한 근거가 필요하다."
],
example:`def sanitize_input(value):
    if not isinstance(value, str):
        raise TypeError("문자열만 허용")
    return value.strip()[:1000]`,
practice:"AI 서비스에 입력할 수 있는 정보와 제한해야 하는 정보를 구분하는 정책을 작성한다.",
challenge:"사내 문서를 AI에 연결하는 서비스의 개인정보 보호 정책을 설계한다.",
checkpoint:"AI 서비스에서 데이터 최소화가 중요한 이유는?"
}
];
