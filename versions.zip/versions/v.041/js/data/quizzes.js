
"use strict";

window.Quizzes = [
  // AI 기초
  ["AI 기초","머신러닝의 핵심 개념은?",
    ["데이터에서 패턴 학습","화면 구성","파일 압축","문자열 출력"],0],
  ["AI 기초","딥러닝의 핵심 구성은?",
    ["신경망","HTML","SQL","CSS"],0],
  ["AI 기초","생성형 AI의 특징은?",
    ["새로운 콘텐츠 생성","파일 삭제","네트워크 차단","화면 출력"],0],

  // 개발 기초
  ["개발 기초","Python에서 함수를 정의하는 키워드는?",
    ["def","function","func","method"],0],
  ["개발 기초","JavaScript의 비동기 처리 키워드는?",
    ["async","static","repeat","class"],0],
  ["개발 기초","JSON은 무엇인가?",
    ["데이터 교환 형식","운영체제","컴파일러","브라우저"],0],

  // Transformer
  ["Transformer","Tokenization의 역할은?",
    ["텍스트를 토큰으로 분리","이미지 압축","모델 배포","데이터 삭제"],0],
  ["Transformer","Embedding의 목적은?",
    ["토큰을 벡터로 표현","파일 저장","화면 렌더링","암호 해제"],0],
  ["Transformer","Self-Attention의 역할은?",
    ["토큰 간 관계 계산","파일 생성","API 인증","이미지 편집"],0],

  // Prompt Engineering
  ["Prompt Engineering","Role은 무엇을 지정하는가?",
    ["AI의 역할","서버 주소","파일 크기","응답 시간"],0],
  ["Prompt Engineering","Few-shot의 특징은?",
    ["예시를 제공","데이터 삭제","모델 중지","코드 압축"],0],
  ["Prompt Engineering","출력 형식 지정의 효과는?",
    ["응답 구조 통제","네트워크 차단","학습 데이터 삭제","모델 교체"],0],

  // Vibe Coding
  ["Vibe Coding","AI 생성 코드에서 반드시 해야 할 것은?",
    ["실행과 검증","무조건 배포","검토 생략","코드 복사만"],0],
  ["Vibe Coding","요구사항 명세의 목적은?",
    ["개발 범위 명확화","디자인 변경","서버 종료","파일 삭제"],0],
  ["Vibe Coding","리팩터링의 목적은?",
    ["구조와 가독성 개선","기능 무조건 추가","데이터 삭제","배포 중단"],0],

  // LLM Development
  ["LLM Development","RAG의 목적은?",
    ["검색 정보를 응답에 활용","모델 삭제","화면 구성","코드 압축"],0],
  ["LLM Development","Vector DB는 주로 무엇을 저장하는가?",
    ["벡터 데이터","HTML 화면","실행 파일","CSS"],0],
  ["LLM Development","API Key는 어떻게 관리하는가?",
    ["환경변수 등 비밀 저장소","공개 코드","화면 표시","Git 업로드"],0],

  // AI Agent
  ["AI Agent","Tool Calling의 목적은?",
    ["외부 도구 실행 요청","문자열 삭제","화면 디자인","모델 학습"],0],
  ["AI Agent","Agent Workflow란?",
    ["작업 단계와 실행 흐름","이미지 형식","CSS 규칙","파일 확장자"],0],
  ["AI Agent","MCP의 역할은?",
    ["AI와 외부 도구 연결 표준화","모델 압축","화면 렌더링","DB 삭제"],0],

  // Deployment
  ["Deployment","단위 테스트의 목적은?",
    ["개별 기능 검증","색상 변경","파일 압축","모델 학습"],0],
  ["Deployment","Docker의 주된 목적은?",
    ["실행 환경 패키징","프롬프트 작성","토큰 분리","모델 추론"],0],
  ["Deployment","모니터링의 목적은?",
    ["운영 상태와 오류 관찰","코드 삭제","모델 이름 변경","디자인 수정"],0]
].map((q, i) => {
  const shift = i % 4;

  // 정답 위치를 4개 보기 사이에 분산
  const options = q[2].map(
    (_, n) => q[2][(n - shift + 4) % 4]
  );

  return {
    id: i + 1,
    domain: q[0],
    question: q[1],
    options,
    answer: (q[3] + shift) % 4
  };
});
