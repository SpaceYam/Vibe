
"use strict";

window.Courses=[
 {id:1,title:"AI 기초",desc:"인공지능의 원리와 생성형 AI 이해",
  lessons:["인공지능의 역사와 발전","머신러닝과 딥러닝","생성형 AI의 원리","LLM의 특징과 한계","AI 윤리와 책임 있는 활용"]},
 {id:2,title:"개발 기초",desc:"소프트웨어와 프로그래밍 기본기",
  lessons:["Python 개발 기초","JavaScript 개발 기초","자료구조와 알고리즘","HTML CSS 웹 구조","HTTP API와 Git"]},
 {id:3,title:"Transformer",desc:"LLM의 내부 구조와 작동 원리",
  lessons:["Tokenization과 토큰","Embedding과 벡터","Self-Attention 원리","Transformer 아키텍처","LLM 추론과 Sampling"]},
 {id:4,title:"Prompt Engineering",desc:"AI의 결과를 통제하는 프롬프트 설계",
  lessons:["프롬프트 기본 구조","Role과 Context 설계","Few-shot과 예제 활용","구조화 출력과 제약 조건","프롬프트 평가와 개선"]},
 {id:5,title:"Vibe Coding",desc:"AI와 협업하는 소프트웨어 개발",
  lessons:["AI 코딩 도구 활용","요구사항과 프로젝트 명세","AI 코드 생성과 분석","디버깅과 코드 검증","리팩터링과 컨텍스트 관리"]},
 {id:6,title:"LLM Development",desc:"실제 LLM 기반 서비스 구현",
  lessons:["LLM API와 응답 처리","Embedding과 Vector DB","RAG 시스템 설계","멀티모달 AI 활용","LLM 애플리케이션 평가"]},
 {id:7,title:"AI Agent",desc:"도구를 사용하는 지능형 시스템",
  lessons:["Agent 구조와 원리","Tool Calling 구현","Agent Workflow 설계","MCP와 외부 도구 연결","Agent 안정성 평가"]},
 {id:8,title:"Deployment",desc:"AI 서비스 테스트와 배포",
  lessons:["테스트와 품질 관리","인증과 AI 보안","Docker와 실행 환경","클라우드 배포와 운영","최종 AI 프로젝트 완성"]}
];
