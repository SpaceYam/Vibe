"use strict";

window.LessonView = {
render(){
const l=Lessons.find(x=>x.id===State.lesson);

if(!l){
return DIL0;
}

const done=Progress.done(l.id);
const concepts=Array.isArray(l.concepts)
?l.concepts:[l.concepts||""];

return `

`;
}
};