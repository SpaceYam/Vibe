"use strict";

window.State = {
page:"home",
profile:null,
completed:[],
notes:{},
before:null,
after:null,
answers:{},
examMode:"diagnostic",
question:0,
lesson:1,
examStarted:{},
examElapsed:{},
assessmentHistory:[],

init(){
const saved=Store.load();
Object.assign(this,saved);
this.answers={};
this.examStarted={};
this.examElapsed={};
},

persist(){
Store.save({
profile:this.profile,
completed:this.completed,
notes:this.notes,
before:this.before,
after:this.after,
assessmentHistory:this.assessmentHistory
});
},

resetExam(mode="diagnostic"){
this.examMode=mode;
this.answers={};
this.examStarted={};
this.examElapsed={};
this.question=0;
}
};
</CodeBlock>

js/features/progress.js
기존 진단 결과가 바뀌면 학습 추천도 자동으로 다시 계산하도록 해.

<CodeBlock language="javascript" editable>
"use strict";

window.Progress = {
total:Lessons.length,

percent(){
return Math.round(
State.completed.length / this.total * 100
);
},

done(id){
return State.completed.includes(id);
},

weakDomains(){
if(!State.before)return [];

return Object.entries(State.before.domains)
.filter(([,v])=>v.score<80)
.map(([name])=>name);
},

priority(){
if(!State.before)return [];

return Object.entries(State.before.domains)
.map(([name,v])=>({
name,
score:v.score,
course:Courses.find(c=>c.title===name)
}))
.filter(x=>x.course)
.sort((a,b)=>a.score-b.score);
},

recommendedLessons(){
const priority=this.priority();

return priority.flatMap(x=>
Lessons.filter(l=>
l.courseId===x.course.id &&
!this.done(l.id)
).map(l=>({
...l,
score:x.score
}))
);
},

finish(){
if(this.percent()<100)return false;
State.persist();
return true;
}
};