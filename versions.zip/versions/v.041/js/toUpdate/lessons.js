
"use strict";

const contentGroups = [
  LessonContent.ai,
  LessonContent.programming,
  LessonContent.transformer,
  LessonContent.prompt,
  LessonContent.vibe,
  LessonContent.llm,
  LessonContent.agent,
  LessonContent.deployment
];

window.Lessons = Courses.flatMap((course, ci) =>
  course.lessons.map((title, li) => {
    const data = contentGroups[ci][li];

    return {
      id: ci * 5 + li + 1,
      courseId: course.id,
      title,
      objective: data.concepts[0],
      concepts: data.concepts,
      theory: data.concepts,
      code: data.example,
      practice: data.practice,
      challenge: data.challenge,
      checkpoint: data.checkpoint
    };
  })
);
