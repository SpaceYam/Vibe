"use strict";

window.HomeView = {
profile(){
return `

`;
},

render(){
const p=State.profile;
if(!p)return this.profile();

return `




`;
}
};