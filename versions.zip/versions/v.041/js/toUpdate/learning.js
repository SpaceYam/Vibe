"use strict";

window.Learning = {
complete(id,note){
if(note.trim().length<5){
App.toast("실습 기록을 5자 이상 작성하세요.");
return;
}

if(!State.completed.includes(id)){
State.completed.push(id);
}

State.notes[id]=note;
State.persist();

Router.go("learning");
App.toast("학습 진도를 저장했습니다.");
},

render(){
const priority=Progress.priority();

return `

$

$

`;
}
};