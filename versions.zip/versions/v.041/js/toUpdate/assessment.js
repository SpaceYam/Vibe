"use strict";

window.AssessmentView = {
question(){
const i=State.question;
const q=Quizzes[i];
const answer=State.answers[i];
const left=Assessment.remaining(i);

return `




$`;
},

render(){
const count=Object.keys(State.answers).length;

return `



`;
}
};