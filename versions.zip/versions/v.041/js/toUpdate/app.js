"use strict";

window.App = {
charts:[],
confirmAction:null,
toastTimer:null,

escape(value){
return String(value??"").replace(/[&<>"']/g,c=>({
"&":"&","<":"<",">":">",
'"':""","'":"'"
})[c]);
},

toast(message){
const el=document.getElementById("toast");
el.textContent=message;
el.classList.add("show");

clearTimeout(this.toastTimer);
this.toastTimer=setTimeout(()=>{
el.classList.remove("show");
},2500);
},

modal(title,message,callback){
const el=document.getElementById("modal");

el.innerHTML=`

`;

el.classList.add("show");
this.confirmAction=callback;
},

closeModal(){
document.getElementById("modal").classList.remove("show");
this.confirmAction=null;
},

updateQuestion(){
const area=document.getElementById("questionArea");
if(area)area.innerHTML=AssessmentView.question();

const count=Object.keys(State.answers).length;

const label=document.getElementById("examCount");
const bar=document.getElementById("examBar");

if(label)label.textContent=$DIL0/$DIL1 완료;
if(bar)bar.style.width=count/Quizzes.length*100+"%";

this.updateTimer(Assessment.remaining(State.question));
},

updateTimer(left){
const q=Quizzes[State.question];
const text=document.getElementById("timerText");
const bar=document.getElementById("timerBar");

if(text){
text.textContent=Math.ceil(left)+"초";
}

if(bar){
const percent=Math.max(0,left/q.seconds*100);
bar.style.width=percent+"%";
bar.classList.toggle("danger",percent<25);
}
},

render(){
Assessment.destroy();
this.charts.forEach(c=>c.destroy());
this.charts=[];

if(!State.profile)State.page="profile";

const pages={
profile:HomeView.profile(),
home:HomeView.render(),
learning:Learning.render(),
lesson:LessonView.render(),
assessment:AssessmentView.render(),
prompt:PromptLab.render(),
report:ReportView.render()
};

document.getElementById("app").innerHTML=      DIL0       DIL1       DIL2    ;

if(State.page==="assessment"){
Assessment.grid=agGrid.createGrid(
document.getElementById("questionGrid"),{
getRowId:p=>String(p.data.no),

rowData:Quizzes.map((q,i)=>({
no:i+1,
domain:q.domain,
question:q.question,
status:State.answers[i]===-1
?"시간 초과"
:State.answers[i]!==undefined
?"✓ 완료"
:"미완료"
})),

columnDefs:[
{field:"no",headerName:"번호",width:75},
{field:"domain",headerName:"영역",width:170},
{field:"question",headerName:"문제",flex:1},
{field:"status",headerName:"상태",width:110}
],

defaultColDef:{
sortable:true,
resizable:true
},

onRowClicked:p=>{
Assessment.select(p.data.no-1);
},

suppressCellFocus:true
}
);
}

if(State.page==="report"){
ReportView.init();
}
},

init(){
State.init();
Events.init();
this.render();
}
};

document.addEventListener(
"DOMContentLoaded",
()=>App.init()
);