"use strict";

window.Assessment = {
grid:null,
timer:null,

start(mode="diagnostic"){
if(mode==="after" && Progress.percent()!==100){
App.toast("전체 학습을 완료해야 사후 평가가 가능합니다.");
return;
}

this.stopTimer();
this.destroy();

State.resetExam(mode);
Router.go("assessment");
this.select(0);
},

destroy(){
this.stopTimer();
if(this.grid){
this.grid.destroy();
this.grid=null;
}
},

stopTimer(){
if(this.timer){
clearInterval(this.timer);
this.timer=null;
}
},

remaining(i){
const q=Quizzes[i];
const started=State.examStarted[i];

if(!started)return q.seconds;

return Math.max(
0,
q.seconds-(Date.now()-started)/1000
);
},

begin(i){
if(State.answers[i]!==undefined)return;

if(!State.examStarted[i]){
State.examStarted[i]=Date.now();
}

this.stopTimer();

this.timer=setInterval(()=>{
const left=this.remaining(i);

App.updateTimer(left);

if(left<=0){
this.timeout(i);
}
},250);
},

select(i){
if(i<0||i>=Quizzes.length)return;

this.stopTimer();
State.question=i;

if(State.answers[i]===undefined){
if(this.remaining(i)<=0 && State.examStarted[i]){
this.timeout(i);
return;
}
this.begin(i);
}

App.updateQuestion();
},

answer(index){
const i=State.question;

if(State.answers[i]!==undefined)return;

if(this.remaining(i)<=0){
this.timeout(i);
return;
}

State.answers[i]=index;
State.examElapsed[i]=
(Quizzes[i].seconds-this.remaining(i));

this.stopTimer();
this.updateGrid(i);
App.updateQuestion();
},

timeout(i){
if(State.answers[i]!==undefined)return;

State.answers[i]=-1;
State.examElapsed[i]=Quizzes[i].seconds;

this.stopTimer();
this.updateGrid(i);
App.updateQuestion();
App.toast("제한 시간이 종료되었습니다.");
},

updateGrid(i){
if(!this.grid)return;

const node=this.grid.getRowNode(String(i+1));
if(node){
node.setDataValue(
"status",
State.answers[i]===-1?"시간 초과":"✓ 완료"
);
}
},

score(){
const domains={};

Courses.forEach(c=>{
const questions=Quizzes
.map((q,i)=>({...q,index:i}))
.filter(q=>q.domain===c.title);

const correct=questions.filter(q=>
State.answers[q.index]===q.answer
).length;

const total=questions.length;

const times=questions.map(q=>
State.examElapsed[q.index]??0
);

domains[c.title]={
score:Math.round(correct/total*100),
correct,
total,
averageTime:Math.round(
times.reduce((a,b)=>a+b,0)/total
),
timeout:questions.filter(q=>
State.answers[q.index]===-1
).length
};
});

const correct=Quizzes.filter((q,i)=>
State.answers[i]===q.answer
).length;

const elapsed=Object.values(State.examElapsed);

return {
total:Math.round(correct/Quizzes.length*100),
domains,
count:Quizzes.length,
correct,
timeout:elapsed.filter((_,i)=>
State.answers[i]===-1
).length,
averageTime:Math.round(
elapsed.reduce((a,b)=>a+b,0)/Quizzes.length
),
completedAt:new Date().toISOString()
};
},

finish(){
// 미응답 문항은 시간 초과와 동일하게 처리
Quizzes.forEach((q,i)=>{
if(State.answers[i]===undefined){
State.answers[i]=-1;
State.examElapsed[i]=0;
}
});

this.stopTimer();

const result=this.score();

State.assessmentHistory.push({
mode:State.examMode,
result
});

if(State.examMode==="after"){
State.after=result;
}else{
// 언제든 재진단 가능
State.before=result;
}

State.persist();
App.closeModal();
Router.go(
State.examMode==="after"?"report":"learning"
);

App.toast("평가 결과가 저장되었습니다.");
}
};