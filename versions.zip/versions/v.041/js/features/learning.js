
"use strict";

window.Learning={
  complete(id,note){
    if(note.trim().length<5){
      App.toast("실습 결과를 5자 이상 작성해 주세요.");
      return;
    }
    if(!State.completed.includes(id))State.completed.push(id);
    State.notes[id]=note;
    State.persist();
    Router.go("learning");
    App.toast("학습 진도를 저장했습니다.");
  },

  render(){
    const weak=Progress.weakDomains();
    return `
      <section class="card">
        <span class="tag">LEARNING ROADMAP</span>
        <h1>AI Vibe Developer 교육과정</h1>
        <div class="between row">
          <b>전체 학습 진행도</b>
          <b>${Progress.percent()}%</b>
        </div>
        <div class="progress">
          <span style="width:${Progress.percent()}%"></span>
        </div>
        <p class="muted">${State.completed.length}/${Lessons.length}개 단원 완료</p>
      </section>

      ${weak.length?`
        <section class="card recommended">
          <h2>우선 학습 영역</h2>
          <p>사전 진단 결과 80점 미만인 영역입니다.</p>
          ${weak.map(x=>`<span class="tag">${App.escape(x)}</span>`).join("")}
        </section>`:""}

      ${Courses.map(c=>`
        <section class="card">
          <span class="tag">LEVEL ${c.id}</span>
          <h2>${c.title}</h2>
          <p class="muted">${c.desc}</p>
          ${Lessons.filter(l=>l.courseId===c.id).map(l=>`
            <div class="lesson-row ${weak.includes(c.title)&&!Progress.done(l.id)?"recommended":""}">
              <div>
                <b>${l.id}. ${l.title}</b>
                <small>${Progress.done(l.id)?"✓ 완료":weak.includes(c.title)?"우선 학습":"학습 전"}</small>
              </div>
              <button class="btn outline" data-action="lesson" data-id="${l.id}">
                ${Progress.done(l.id)?"복습":"학습하기"}
              </button>
            </div>`).join("")}
        </section>`).join("")}

      <section class="card">
        <h2>학습 완료 및 사후 평가</h2>
        <p>전체 단원 완료 후 사후 평가를 진행할 수 있습니다.</p>
        <button class="btn teal" data-action="final"
          ${Progress.percent()!==100?"disabled":""}>사후 평가 시작</button>
      </section>`;
  }
};
