
"use strict";

window.Progress={
  total:Lessons.length,

  percent(){
    return Math.round(State.completed.length/this.total*100);
  },

  done(id){
    return State.completed.includes(id);
  },

  weakDomains(){
    if(!State.before)return [];
    return Object.entries(State.before.domains)
      .filter(([,v])=>v.score<80)
      .map(([name])=>name);
  },

  finish(){
    if(this.percent()<100)return false;
    State.persist();
    return true;
  }
};
