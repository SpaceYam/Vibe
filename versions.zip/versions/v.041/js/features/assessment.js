
"use strict";

window.Assessment={
  grid:null,

  start(mode){
    if(mode==="pre"&&State.before){
      App.toast("사전 평가가 이미 완료되었습니다.");return;
    }
    if(mode==="after"&&Progress.percent()!==100){
      App.toast("40개 단원을 모두 완료해야 합니다.");return;
    }
    State.resetExam(mode);
    Router.go("assessment");
  },

  select(i){
    if(i<0||i>=Quizzes.length)return;
    State.question=i;
    App.updateQuestion();
  },

  answer(i){
    const n=State.question;
    if(State.answers[n]!==undefined)return;
    State.answers[n]=i;
    this.grid?.getRowNode(String(n+1))
      ?.setDataValue("status","✓ 완료");
    App.updateQuestion();
  },

  confidence(v){
    const n=State.question;
    if(State.answers[n]===undefined){
      App.toast("먼저 답변을 선택하세요.");return;
    }
    State.confidence[n]=v;
    App.updateQuestion();
  },

  score(){
    const domains={};
    Courses.forEach(c=>{
      const qs=Quizzes.map((q,i)=>({...q,index:i}))
        .filter(q=>q.domain===c.title);
      const correct=qs.filter(q=>
        State.answers[q.index]===q.answer
      ).length;
      const confident=qs.filter(q=>
        State.confidence[q.index]>=2
      ).length;
      domains[c.title]={
        score:Math.round(correct/qs.length*100),
        correct,total:qs.length,
        confident
      };
    });
    const correct=Quizzes.filter((q,i)=>
      State.answers[i]===q.answer
    ).length;
    return {
      total:Math.round(correct/Quizzes.length*100),
      domains,count:Quizzes.length,
      confidence:Object.values(State.confidence)
        .reduce((a,b)=>a+b,0)
    };
  },

  finish(){
    if(Object.keys(State.answers).length!==Quizzes.length){
      App.toast("모든 문제에 답변해 주세요.");return;
    }
    if(Object.keys(State.confidence).length!==Quizzes.length){
      App.toast("모든 문제의 확신도를 선택해 주세요.");return;
    }
    const result=this.score();
    if(State.examMode==="pre")State.before=result;
    else State.after=result;
    State.persist();
    App.closeModal();
    Router.go(State.examMode==="pre"?"learning":"report");
    App.toast("평가가 완료되었습니다.");
  },

  destroy(){
    if(this.grid){
      this.grid.destroy();
      this.grid=null;
    }
  }
};
