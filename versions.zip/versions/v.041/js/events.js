
"use strict";

window.Events={
  init(){
    document.addEventListener("click",e=>{
      const el=e.target.closest("[data-action]");
      if(!el)return;

      const action=el.dataset.action;
      const id=Number(el.dataset.id);
      const index=Number(el.dataset.index);

      switch(action){
        case "home":
          Router.go("home");break;

        case "learning":
          Router.go("learning");break;

        case "prompt":
          Router.go("prompt");break;

        case "report":
          Router.go("report");break;

        case "save-profile":{
          const get=id=>document.getElementById(id).value.trim();
          const name=get("pName");
          const project=get("pProject");
          if(!name||!project){
            App.toast("이름과 프로젝트 목표를 입력하세요.");
            break;
          }
          State.profile={
            name,goal:get("pGoal"),dev:get("pDev"),
            ai:get("pAI"),time:get("pTime"),project
          };
          State.persist();
          Router.go("home");
          App.toast("프로필이 생성되었습니다.");
          break;
        }

        case "pre":
          Assessment.start("pre");break;

        case "final":
          App.modal(
            "사후 평가 시작",
            "모든 학습 단원을 완료했습니다. 사후 평가를 시작할까요?",
            ()=>Assessment.start("after")
          );
          break;

        case "lesson":
          Router.lesson(id);break;

        case "lesson-complete":{
          const note=document.getElementById("lessonNote").value;
          Learning.complete(id,note);
          break;
        }

        case "answer":
          Assessment.answer(index);break;

        case "confidence":
          Assessment.confidence(Number(el.dataset.value));break;

        case "prev":
          Assessment.select(State.question-1);break;

        case "next":
          Assessment.select(State.question+1);break;

        case "finish":
          App.modal(
            "평가 제출",
            "제출하면 답변을 수정할 수 없습니다. 제출할까요?",
            ()=>Assessment.finish()
          );
          break;

        case "generate-prompt":
          PromptLab.generate();break;

        case "copy-prompt":
          PromptLab.copy();break;

        case "confirm":
          App.confirmAction?.();break;

        case "cancel":
          App.closeModal();break;
      }
    });
  }
};
