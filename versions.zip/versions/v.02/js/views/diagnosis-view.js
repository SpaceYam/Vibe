"use strict";
window.DiagnosisView = {
 render(){
  const before=Store.get("before");
  return `
  <section class="card">
   <span class="tag">PERSONAL SKILL ASSESSMENT</span>
   <h1>나의 AI 활용 역량 진단</h1>
   <p>12개 문항으로 여섯 가지 역량을 평가합니다.</p>
   <div class="item">
    <h3>평가 영역</h3>
    <p>AI 원리 · 프롬프트 · 코딩 · 디버깅 · 문제 분석 · 프로젝트</p>
   </div>
   <div class="item">
    <h3>평가 방식</h3>
    <p>영역별 2문항, 문항별 0~3점으로 채점합니다. 정답과 오답을 포함한 결과를 저장합니다.</p>
   </div>
   ${before?'<p class="muted">기존 사전 진단이 있습니다. 새 진단을 진행하면 이전 결과가 교체됩니다.</p>':''}
   <button class="btn primary" data-action="start-diagnosis">진단 시작하기</button>
  </section>`;
 }
};