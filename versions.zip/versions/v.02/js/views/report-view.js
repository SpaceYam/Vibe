"use strict";
window.ReportView = {
 render(){
  const r=Analytics.get();
  if(!r)return "<section class='card'>성과 데이터가 없습니다.</section>";
  const before=r.before,after=r.after;
  const avg=x=>Math.round(Object.values(x.scores).reduce((a,b)=>a+b,0)/6);
  return `
  <section class="card">
   <span class="tag">LEARNING PERFORMANCE</span>
   <h1>나의 학습 성과 보고서</h1>
   <div class="stats">
    <div class="stat"><strong>${avg(before)}</strong>교육 전 평균</div>
    <div class="stat"><strong>${avg(after)}</strong>교육 후 평균</div>
    <div class="stat"><strong class="delta">+${avg(after)-avg(before)}</strong>평균 향상</div>
   </div>
   <h2>역량별 Before / After 비교</h2>
   <div class="dual">
    <div class="muted" style="text-align:center">교육 전 ←</div>
    <div class="muted" style="text-align:center">→ 교육 후</div>
   </div>
   ${r.differences.map(d=>`
    <div class="bar-row">
     <div class="bar-label">
      <strong>${Analytics.label(d.key)}</strong>
      <span class="${d.delta>=0?"delta":"muted"}">
       ${d.delta>0?"+":""}${d.delta}점
      </span>
     </div>
     <div class="dual">
      <div class="dual-side left">
       <span class="dual-bar" style="width:${d.before}%"></span>
      </div>
      <div class="dual-side right">
       <span class="dual-bar" style="width:${d.after}%"></span>
      </div>
     </div>
     <div class="dual">
      <small class="muted" style="text-align:right">${d.before}점</small>
      <small class="muted">${d.after}점</small>
     </div>
    </div>`).join("")}
   <div class="item">
    <span class="pill">교육 성과</span>
    <p>총 6개 역량 영역의 교육 전후 점수를 비교했습니다. 점수 변화는 동일한 진단 기준에 따른 자기 역량 평가 결과입니다.</p>
   </div>
   <h2>다음 학습 추천</h2>
   ${r.differences.filter(d=>d.after<80).sort((a,b)=>a.after-b.after).map(d=>`
    <div class="item"><strong>${Analytics.label(d.key)}</strong>
    <p>현재 ${d.after}점입니다. 해당 영역의 실습과 프로젝트를 추가로 진행하는 것을 추천합니다.</p></div>
   `).join("")||'<p>모든 영역에서 80점 이상입니다. 실전 프로젝트로 확장해 보세요.</p>'}
   <button class="btn primary" data-action="receipt">학습 Receipt 보기</button>
   <button class="btn" data-action="export-receipt">Receipt 다운로드</button>
   <button class="btn" data-action="home">홈으로</button>
  </section>`;
 }
};