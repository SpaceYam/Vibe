"use strict";
window.WorkflowView = {
 render(){
  const w=Workflow.get();
  if(!w)return DiagnosisView.render();
  const r=Receipt.get()||{completed:[]};
  const count=r.completed.length;
  const percent=Math.round(count/w.steps.length*100);
  return `
  <section class="card">
   <span class="tag">YOUR PERSONAL WORKFLOW</span>
   <h1>나만의 학습 과정</h1>
   <p>진단 결과를 기준으로 부족한 영역을 우선 학습하도록 구성했습니다.</p>
   <div class="stats">
    <div class="stat"><strong>${w.steps.length}</strong>학습 단계</div>
    <div class="stat"><strong>${count}</strong>완료</div>
    <div class="stat"><strong>${percent}%</strong>진행률</div>
   </div>
   <div class="progress"><span style="width:${percent}%"></span></div>
   <h2>학습 영역별 진단 점수</h2>
   ${Object.entries(w.scores).map(([k,v])=>`
    <div class="item">${Analytics.label(k)}
     <strong style="float:right">${v}점</strong>
     <div class="progress"><span style="width:${v}%"></span></div>
    </div>`).join("")}
   <h2>개인별 학습 단계</h2>
   ${w.steps.map(s=>{
    const completed=r.completed.includes(s.id);
    return `<div class="item">
     <span class="pill">${completed?"완료":"학습 대기"}</span>
     <h3>${s.order}. ${s.title}</h3>
     <button class="btn ${completed?"":"primary"}"
      data-action="workflow-lesson" data-id="${s.id}">
      ${completed?"다시 보기":"학습하기"}
     </button>
    </div>`;
   }).join("")}
   ${Workflow.isComplete()?`
    <div class="item">
     <h2>모든 학습 단계를 완료했습니다!</h2>
     <p>이제 교육 성과를 측정할 사후 진단을 진행하세요.</p>
     <button class="btn primary" data-action="start-post">사후 역량 진단</button>
    </div>`:""}
  </section>`;
 }
};