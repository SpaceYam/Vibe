"use strict";
window.LessonView = {
 render(course,index){
  const list=LessonData.filter(x=>x.course===course);
  const l=list[index];
  if(!l)return "<section class='card'>학습 자료가 없습니다.</section>";
  const done=Progress.get().includes(l.id);
  return `
  <section class="card">
   <span class="tag">LESSON ${index+1}</span>
   <h1>${l.title}</h1>
   <div class="lesson-content">${l.body}</div>
   <h2>실전 과제</h2>
   <div class="item">${l.task}</div>
   <textarea class="field" id="practice-answer" rows="5"
    placeholder="과제를 수행한 내용과 답변을 작성하세요.">${Practice.get(l.id)}</textarea>
   <p class="muted">작성한 내용은 이 브라우저에 저장됩니다.</p>
   <button class="btn" data-action="save-practice" data-id="${l.id}">답변 저장</button>
   <button class="btn primary" data-action="complete-lesson"
    data-id="${l.id}" ${done?"disabled":""}>
    ${done?"학습 완료":"학습 완료 처리"}
   </button>
   <p><button class="btn" data-action="course" data-id="${course}">목차로</button></p>
  </section>`;
 }
};