"use strict";
window.CourseView = {
 render(id){
  const c=CourseData.find(x=>x.id===id);
  if(!c)return "<section class='card'>과정을 찾을 수 없습니다.</section>";
  const lessons=LessonData.filter(x=>x.course===id);
  return `
  <section class="card">
   <span class="tag">${c.category.toUpperCase()}</span>
   <h1>${c.name}</h1><p>${c.desc}</p>
   <h2>학습 목차</h2>
   ${lessons.map((l,i)=>`
    <div class="item">
     <strong>${i+1}. ${l.title}</strong>
     <p class="muted">${l.task}</p>
     <button class="btn" data-action="lesson"
      data-id="${id}" data-index="${i}">학습하기</button>
    </div>`).join("")}
   <button class="btn" data-action="home">홈으로</button>
  </section>`;
 }
};