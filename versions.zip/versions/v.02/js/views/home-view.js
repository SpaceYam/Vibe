"use strict";
window.HomeView = {
 render(){
  const before=Store.get("before");
  const workflow=Workflow.get();
  const receipt=Receipt.get();
  const courses=CourseData;
  return `
  <section class="card hero">
   <span class="tag">AI CODING ACADEMY</span>
   <h1>AI와 함께 만드는<br>나만의 개발 능력</h1>
   <p>현재 실력을 진단하고 부족한 역량을 집중적으로 학습하세요.</p>
   <button class="btn primary" data-action="${before?"workflow":"diagnosis"}">
    ${before?"나의 학습과정 확인하기":"나의 역량 진단 시작하기"}
   </button>
  </section>
  ${before?`
  <section class="card">
   <h2>나의 현재 학습 상태</h2>
   <div class="stats">
    <div class="stat"><strong>${before.total}</strong>사전 진단 점수</div>
    <div class="stat"><strong>${workflow?.steps.length||0}</strong>맞춤 학습 단계</div>
    <div class="stat"><strong>${receipt?.completed?.length||0}</strong>완료한 학습</div>
   </div>
   <p><button class="btn primary" data-action="workflow">학습 계속하기 →</button></p>
   ${Store.get("after")?'<button class="btn" data-action="report">성과 보고서 보기</button>':''}
  </section>`:""}
  <h2>교육 커리큘럼</h2>
  <div class="grid">
  ${courses.map(c=>`
   <article class="card">
    <span class="tag">${c.category.toUpperCase()}</span>
    <h3>${c.name}</h3><p class="muted">${c.desc}</p>
    <button class="btn" data-action="course" data-id="${c.id}">과정 살펴보기</button>
   </article>`).join("")}
  </div>
  <section class="card">
   <h2>나의 학습 기록</h2>
   <p class="muted">사전 진단과 교육 이수 내역은 이 브라우저에 저장됩니다.</p>
   <button class="btn" data-action="receipt">학습 Receipt 확인</button>
  </section>`;
 }
};