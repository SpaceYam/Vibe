"use strict";
window.ToolView = {
 prompt(){
  return `
  <section class="card">
   <span class="tag">PROMPT LAB</span>
   <h1>프롬프트 생성 도우미</h1>
   <p>만들고 싶은 기능을 구체적으로 작성하세요.</p>
   <textarea id="prompt-input" class="field" rows="5"
    placeholder="예: 회원가입이 가능한 쇼핑몰"></textarea>
   <button class="btn primary" data-action="make-prompt">프롬프트 생성</button>
   <pre id="prompt-output" class="item"></pre>
  </section>`;
 },
 code(){
  return `
  <section class="card">
   <h1>코드 학습 도우미</h1>
   <p>코드를 입력하면 AI에게 전달할 코드 리뷰 요청문을 구성합니다.</p>
   <textarea id="code-input" class="field" rows="10"
    placeholder="검토할 코드를 입력하세요."></textarea>
   <button class="btn primary" data-action="review-code">리뷰 요청문 생성</button>
   <pre id="code-output" class="item"></pre>
  </section>`;
 },
 projects(){
  return `
  <h1>실전 프로젝트</h1>
  <p class="muted">작은 기능부터 구현하며 개발 과정을 경험하세요.</p>
  ${ProjectData.map(p=>`
   <section class="card">
    <span class="tag">${p.level}</span>
    <h2>${p.name}</h2><p>${p.desc}</p>
    ${p.tasks.map((t,i)=>`<div class="item">${i+1}. ${t}</div>`).join("")}
   </section>`).join("")}`;
 },
 glossary(){
  return `
  <section class="card">
   <h1>AI · 개발 용어사전</h1>
   <input class="field" id="glossary-search" placeholder="용어 검색">
   <div id="glossary-list">
   ${Glossary.map(g=>`
    <div class="item"><strong>${g[0]}</strong><p>${g[1]}</p></div>
   `).join("")}
   </div>
  </section>`;
 }
};