"use strict";
window.State = {
 page:"home",course:null,lesson:null,
 quizIndex:0,quizAnswers:{},quizMode:"pre",
 diagnosis:null,workflow:null,
 lessonIndex:0,receipt:null,
 practiceText:"",glossaryQuery:""
};