"use strict";
window.Store = {
 key:"vibeSchool_v3",
 read(){
  try{return JSON.parse(localStorage.getItem(this.key))||{}}
  catch{return {}}
 },
 write(data){
  localStorage.setItem(this.key,JSON.stringify(data));
 },
 get(key,def=null){return this.read()[key]??def},
 set(key,value){
  const data=this.read();data[key]=value;this.write(data);
 },
 clear(){localStorage.removeItem(this.key)}
};