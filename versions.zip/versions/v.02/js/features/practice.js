"use strict";
window.Practice = {
 save(id,text){
  const data=Store.get("practice",{});
  data[id]=text;
  Store.set("practice",data);
 },
 get(id){return Store.get("practice",{})[id]||""},
 prompt(text){
  return `당신은 숙련된 바이브코딩 강사입니다.
목표: ${text}
다음 순서로 답변하세요.
1. 요구사항 분석
2. 구현 계획
3. 코드 작성
4. 실행 및 검증 방법
5. 초보자가 주의할 점`;
 },
 copy(text){
  navigator.clipboard?.writeText(text)
   .then(()=>alert("복사했습니다."))
   .catch(()=>alert("복사할 수 없습니다."));
 }
};