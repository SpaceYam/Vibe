"use strict";
window.Receipt = {
 get(){return Store.get("receipt",null)},
 export(){
  const data=this.get();
  if(!data)return;
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(blob);
  a.download="vibe-school-receipt.json";
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
 },
 summary(){
  const r=this.get();
  if(!r)return null;
  return {
   id:r.id,before:r.before,
   workflow:r.workflow,completed:r.completed,
   after:Store.get("after")
  };
 }
};