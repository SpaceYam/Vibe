"use strict";
window.Diagnosis = {
 start(mode="pre"){
  State.quizMode=mode;
  State.quizIndex=0;
  State.quizAnswers={};
  Router.go("quiz");
 },
 answer(index){
  const q=QuizData[index];
  const score=q.options[State.quizAnswers[index]]?.score;
  if(score===undefined)return;
  if(index<QuizData.length-1){
   State.quizIndex++;
   App.render();
  }else this.finish();
 },
 finish(){
  const totals={},counts={};
  ["ai","prompt","coding","debug","logic","project"].forEach(k=>{
   totals[k]=0;counts[k]=0;
  });
  QuizData.forEach((q,i)=>{
   totals[q.category]+=q.options[State.quizAnswers[i]].score;
   counts[q.category]++;
  });
  const scores={};
  Object.keys(totals).forEach(k=>{
   scores[k]=Math.round(totals[k]/(counts[k]*3)*100);
  });
  const result={
   date:new Date().toISOString(),
   answers:{...State.quizAnswers},
   scores,
   total:Math.round(Object.values(scores).reduce((a,b)=>a+b,0)/6)
  };
  if(State.quizMode==="pre"){
   State.diagnosis=result;
   Store.set("before",result);
   Workflow.create(scores);
   Router.go("workflow");
  }else{
   Store.set("after",result);
   Analytics.saveReport();
   Router.go("report");
  }
 }
};