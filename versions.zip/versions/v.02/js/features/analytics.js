"use strict";
window.Analytics = {
 labels:{
  ai:"AI 기본 원리",
  prompt:"프롬프트 설계",
  coding:"코딩 기초",
  debug:"디버깅 및 검증",
  logic:"문제 분석 능력",
  project:"프로젝트 수행"
 },
 label(key){return this.labels[key]||key},
 saveReport(){
  const r=Receipt.get();
  if(!r)return;
  const after=Store.get("after");
  const before=r.before;
  const report={
   before,after,
   differences:Object.keys(before.scores).map(key=>({
    key,before:before.scores[key],
    after:after.scores[key],
    delta:after.scores[key]-before.scores[key]
   }))
  };
  Store.set("report",report);
  r.after=after;
  r.finishedAt=new Date().toISOString();
  r.status="completed";
  Store.set("receipt",r);
 },
 get(){return Store.get("report",null)}
};