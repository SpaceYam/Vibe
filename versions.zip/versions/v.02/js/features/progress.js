"use strict";
window.Progress = {
 get(){return Store.get("completed",[])},
 done(id){
  const list=this.get();
  if(!list.includes(id))list.push(id);
  Store.set("completed",list);
 },
 percent(ids){
  if(!ids.length)return 0;
  const done=this.get();
  return Math.round(ids.filter(id=>done.includes(id)).length/ids.length*100);
 },
 reset(){Store.set("completed",[])}
};