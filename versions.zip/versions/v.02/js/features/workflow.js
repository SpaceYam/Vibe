"use strict";
window.Workflow = {
 create(scores){
  const courses=CourseData;
  const weak=Object.entries(scores).sort((a,b)=>a[1]-b[1]);
  const selected=weak.filter(x=>x[1]<80).map(x=>x[0]);
  if(!selected.length)selected.push(weak[0][0]);
  const lessons=LessonData.filter(x=>
   selected.includes(CourseData.find(c=>c.id===x.course)?.category)
  );
  const workflow={
   id:Date.now(),createdAt:new Date().toISOString(),
   scores,weak:selected,
   steps:lessons.map((x,i)=>({
    id:x.id,title:x.title,course:x.course,order:i+1
   })),
   status:"active"
  };
  State.workflow=workflow;
  Store.set("workflow",workflow);
  Store.set("receipt",{
   id:workflow.id,createdAt:workflow.createdAt,
   before:State.diagnosis,workflow,completed:[]
  });
  return workflow;
 },
 get(){return Store.get("workflow")},
 complete(id){
  const w=this.get();
  if(!w)return;
  const receipt=Store.get("receipt",{});
  if(!receipt.completed.includes(id))receipt.completed.push(id);
  Store.set("receipt",receipt);
  const all=w.steps.every(s=>receipt.completed.includes(s.id));
  if(all){
   w.status="ready";
   Store.set("workflow",w);
  }
 },
 isComplete(){
  const w=this.get();
  const r=Store.get("receipt",{});
  return !!w&&w.steps.every(s=>r.completed?.includes(s.id));
 }
};