"use strict";
window.Quiz = {
 view(){
  const q=QuizData[State.quizIndex];
  const selected=State.quizAnswers[State.quizIndex];
  return `
  <section class="card">
   <span class="tag">${State.quizMode==="pre"?"사전 진단":"사후 진단"}</span>
   <h1>역량 진단 테스트</h1>
   <p class="muted">QUESTION ${State.quizIndex+1} / ${QuizData.length}</p>
   <div class="progress"><span style="width:${(State.quizIndex+1)/QuizData.length*100}%"></span></div>
   <h2>${q.question}</h2>
   ${q.options.map((o,i)=>`
    <button class="option ${selected==i?"selected":""}"
     data-action="quiz-answer" data-index="${i}">
     ${String.fromCharCode(65+i)}. ${o.text}
    </button>`).join("")}
   <p class="muted">정답을 선택하면 다음 문제로 이동합니다.</p>
   <button class="btn" data-action="quiz-prev">이전</button>
  </section>`;
 },
 select(i){
  State.quizAnswers[State.quizIndex]=i;
  if(State.quizIndex<QuizData.length-1)State.quizIndex++;
  else{Diagnosis.finish();return}
  App.render();
 }
};