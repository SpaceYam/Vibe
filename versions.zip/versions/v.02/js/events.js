"use strict";
window.Events = {
 init(){
  document.addEventListener("click",e=>{
   const el=e.target.closest("[data-action]");
   if(!el)return;
   const a=el.dataset.action;
   const id=el.dataset.id;
   const index=Number(el.dataset.index);

   switch(a){
    case "home":Router.home();break;
    case "diagnosis":Router.go("diagnosis");break;
    case "start-diagnosis":Diagnosis.start("pre");break;
    case "start-post":Diagnosis.start("post");break;
    case "quiz-answer":Quiz.select(index);break;
    case "quiz-prev":
     if(State.quizIndex>0)State.quizIndex--;
     App.render();break;
    case "course":Router.course(id);break;
    case "lesson":Router.lesson(id,index);break;
    case "workflow":Router.go("workflow");break;
    case "workflow-lesson":{
     const l=LessonData.find(x=>x.id===id);
     const i=LessonData.filter(x=>x.course===l.course)
      .findIndex(x=>x.id===id);
     Router.lesson(l.course,i);break;
    }
    case "save-practice":{
     Practice.save(id,document.getElementById("practice-answer").value);
     alert("답변을 저장했습니다.");break;
    }
    case "complete-lesson":
     Progress.done(id);
     Workflow.complete(id);
     App.render();break;
    case "projects":Router.go("projects");break;
    case "glossary":Router.go("glossary");break;
    case "prompt":Router.go("prompt");break;
    case "code":Router.go("code");break;
    case "report":Router.go("report");break;
    case "receipt":Router.go("receipt");break;
    case "export-receipt":Receipt.export();break;
    case "make-prompt":{
     const text=document.getElementById("prompt-input").value;
     document.getElementById("prompt-output").textContent=
      Practice.prompt(text);
     break;
    }
    case "review-code":{
     const code=document.getElementById("code-input").value;
     document.getElementById("code-output").textContent=
      Practice.prompt("다음 코드를 검토하고 보안, 오류, 성능, 가독성을 평가하세요.\n"+code);
     break;
    }
   }
  });

  document.addEventListener("input",e=>{
   if(e.target.id==="glossary-search"){
    const q=e.target.value.toLowerCase();
    document.querySelectorAll("#glossary-list .item")
     .forEach((el,i)=>{
      el.style.display=Glossary[i][0].toLowerCase().includes(q)||
       Glossary[i][1].toLowerCase().includes(q)?"":"none";
     });
   }
  });
 }
};