"use strict";
window.App = {
 render(){
  let content="";
  switch(State.page){
   case "home":content=HomeView.render();break;
   case "course":content=CourseView.render(State.course);break;
   case "lesson":content=LessonView.render(State.course,State.lesson);break;
   case "prompt":content=ToolView.prompt();break;
   case "code":content=ToolView.code();break;
   case "quiz":content=Quiz.view();break;
   case "projects":content=ToolView.projects();break;
   case "glossary":content=ToolView.glossary();break;
   case "diagnosis":content=DiagnosisView.render();break;
   case "workflow":content=WorkflowView.render();break;
   case "report":content=ReportView.render();break;
   case "receipt":content=this.receiptView();break;
   default:content=HomeView.render();
  }
  document.getElementById("app").innerHTML=this.shell(content);
 },
 shell(content){
  return `
  <div class="shell">
   <header class="topbar">
    <a class="logo" href="#" data-action="home">VIBE<span>SCHOOL</span></a>
    <nav class="nav">
     <button data-action="home">홈</button>
     <button data-action="projects">프로젝트</button>
     <button data-action="prompt">프롬프트</button>
     <button data-action="code">코딩</button>
     <button data-action="quiz">퀴즈</button>
     <button data-action="glossary">용어사전</button>
    </nav>
   </header>
   <main class="main">${content}</main>
   <footer class="footer">VIBE SCHOOL © 2026 · LEARN AND BUILD WITH AI</footer>
  </div>`;
 },
 receiptView(){
  const r=Receipt.get();
  if(!r)return `<section class="card"><h1>학습 Receipt</h1><p>저장된 기록이 없습니다.</p></section>`;
  return `
  <section class="card">
   <span class="tag">LEARNING RECEIPT</span>
   <h1>학습 이수 기록</h1>
   <div class="item"><strong>Receipt ID</strong><p>${r.id}</p></div>
   <div class="item"><strong>진단 일시</strong><p>${r.createdAt}</p></div>
   <div class="item"><strong>사전 진단 평균</strong><p>${r.before.total}점</p></div>
   <div class="item"><strong>완료한 학습</strong><p>${r.completed.length} / ${r.workflow.steps.length}</p></div>
   <div class="item"><strong>교육 상태</strong><p>${r.status==="completed"?"교육 및 사후 진단 완료":"학습 진행 중"}</p></div>
   ${r.after?`<div class="item"><strong>사후 진단 평균</strong><p>${r.after.total}점</p></div>`:""}
   <h2>학습 단계 기록</h2>
   ${r.workflow.steps.map(s=>`
    <div class="item">${s.title}
    <span class="pill">${r.completed.includes(s.id)?"완료":"미완료"}</span>
    </div>`).join("")}
   <button class="btn primary" data-action="export-receipt">JSON Receipt 다운로드</button>
   ${r.after?'<button class="btn" data-action="report">성과 보고서</button>':''}
   <button class="btn" data-action="home">홈으로</button>
  </section>`;
 },
 init(){
  Events.init();
  this.render();
 }
};
document.addEventListener("DOMContentLoaded",()=>App.init());