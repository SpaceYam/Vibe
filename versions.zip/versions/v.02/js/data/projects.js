"use strict";
window.ProjectData = [
{id:"counter",name:"카운터 앱",level:"초급",
desc:"버튼을 눌러 숫자를 증가·감소시키는 앱",
tasks:["HTML로 숫자와 버튼 구성","CSS로 화면 꾸미기","JS로 증가·감소 구현","0 이하 처리 검증"]},
{id:"todo",name:"할 일 관리 앱",level:"초중급",
desc:"할 일 등록, 완료, 삭제, 저장 기능",
tasks:["입력 폼 구성","목록 렌더링","완료 및 삭제","LocalStorage 저장"]},
{id:"prompt",name:"AI 프롬프트 실험실",level:"초중급",
desc:"프롬프트 조건에 따른 응답 품질 비교",
tasks:["목표 정의","기본 프롬프트 작성","조건 추가","결과 비교 및 기록"]},
{id:"portfolio",name:"개인 포트폴리오",level:"중급",
desc:"자기소개와 프로젝트를 소개하는 반응형 웹",
tasks:["페이지 구조 설계","반응형 CSS","프로젝트 데이터 구성","접근성 및 테스트"]}
];