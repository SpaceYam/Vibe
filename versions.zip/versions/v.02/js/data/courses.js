"use strict";
window.CourseData = [
{id:"ai",name:"AI 작동 원리",category:"ai",level:1,
desc:"생성형 AI와 언어모델의 작동 구조를 이해합니다."},
{id:"prompt",name:"프롬프트 엔지니어링",category:"prompt",level:1,
desc:"AI에게 정확한 작업을 요청하고 결과를 개선합니다."},
{id:"web",name:"웹 개발 기초",category:"coding",level:1,
desc:"HTML, CSS, JavaScript의 역할과 구조를 이해합니다."},
{id:"debug",name:"디버깅과 검증",category:"debug",level:2,
desc:"오류를 재현하고 원인을 찾아 수정합니다."},
{id:"logic",name:"문제 분석과 설계",category:"logic",level:2,
desc:"요구사항을 기능과 데이터 구조로 분해합니다."},
{id:"build",name:"바이브코딩 프로젝트",category:"project",level:2,
desc:"AI와 협업해 실제 서비스를 기획하고 완성합니다."}
];