
"use strict";

window.Report = {
  charts:[],

  render(){
    if(!State.before||!State.after){
      return `<div class="card">
        <h2>리포트가 없습니다.</h2>
        <button class="btn primary" data-action="home">홈으로</button>
      </div>`;
    }

    const b=State.before,a=State.after;
    const diff=a.total-b.total;

    return `
      <div class="card">
        <h1>학습 성과 리포트</h1>
        <p class="muted">사전 진단과 사후 진단 결과 비교</p>
        <div class="grid">
          <div class="stat">
            <span class="muted">BEFORE</span>
            <strong>${b.total}점</strong>
          </div>
          <div class="stat">
            <span class="muted">AFTER</span>
            <strong>${a.total}점</strong>
          </div>
          <div class="stat">
            <span class="muted">점수 변화</span>
            <strong style="color:${diff>=0?"#398b82":"#b75c5c"}">
              ${diff>0?"+":""}${diff}점
            </strong>
          </div>
        </div>
      </div>

      <div class="card">
        <h2>역량별 사전·사후 점수 비교</h2>
        <p class="muted">
          동일한 0~100점 축에서 두 평가 결과를 비교합니다.
        </p>
        <div class="chart-box">
          <canvas id="compareChart"></canvas>
        </div>
      </div>

      <div class="card">
        <h2>기술 능력치 분석</h2>
        <p class="muted">
          각 역량 영역의 사전·사후 점수 변화
        </p>
        <div class="chart-box">
          <canvas id="radarChart"></canvas>
        </div>
      </div>

      <div class="card">
        <h2>영역별 상세 결과</h2>
        ${DB.domains.map(d=>`
          <div style="margin:20px 0">
            <div class="row between">
              <strong>${d}</strong>
              <span>${b.domains[d]} → ${a.domains[d]}점</span>
            </div>
            <div class="progress">
              <span style="width:${a.domains[d]}%"></span>
            </div>
          </div>
        `).join("")}
      </div>

      <div class="card">
        <h2>평가 결과 해석</h2>
        <p>
          총점 변화: ${diff>0?"+":""}${diff}점
        </p>
        <p class="muted">
          각 영역은 4문항으로 평가되었습니다.
          문항 수가 적으므로 본 결과는 학습 방향을 위한
          진단 참고 자료이며 객관적인 전문 역량 인증 점수는 아닙니다.
        </p>
      </div>
      <button class="btn primary" data-action="home">홈으로 돌아가기</button>`;
  },

  init(){
    this.destroy();
    const b=State.before,a=State.after;
    if(!b||!a)return;

    const labels=DB.domains;
    this.charts.push(new Chart(
      document.getElementById("compareChart"),{
        type:"bar",
        data:{
          labels,
          datasets:[
            {
              label:"Before",
              data:labels.map(d=>b.domains[d]),
              backgroundColor:"#AEBBC9",
              borderRadius:5,
              grouped:false,
              barThickness:15,
              order:2
            },
            {
              label:"After",
              data:labels.map(d=>a.domains[d]),
              backgroundColor:"#398B82",
              borderRadius:5,
              grouped:false,
              barThickness:8,
              order:1
            }
          ]
        },
        options:{
          indexAxis:"y",
          responsive:true,
          maintainAspectRatio:false,
          scales:{
            x:{min:0,max:100,
              title:{display:true,text:"점수"},
              grid:{color:"#edf1f5"}
            },
            y:{grid:{display:false}}
          },
          plugins:{
            legend:{position:"bottom"},
            tooltip:{mode:"index",intersect:false}
          }
        }
      }
    ));

    this.charts.push(new Chart(
      document.getElementById("radarChart"),{
        type:"radar",
        data:{
          labels,
          datasets:[
            {
              label:"Before",
              data:labels.map(d=>b.domains[d]),
              borderColor:"#91A3B8",
              backgroundColor:"#91A3B822",
              pointBackgroundColor:"#91A3B8"
            },
            {
              label:"After",
              data:labels.map(d=>a.domains[d]),
              borderColor:"#398B82",
              backgroundColor:"#398B8230",
              pointBackgroundColor:"#398B82"
            }
          ]
        },
        options:{
          responsive:true,
          maintainAspectRatio:false,
          scales:{
            r:{
              min:0,max:100,
              ticks:{stepSize:20},
              pointLabels:{font:{size:12}}
            }
          },
          plugins:{legend:{position:"bottom"}}
        }
      }
    ));
  },

  destroy(){
    this.charts.forEach(c=>c.destroy());
    this.charts=[];
  }
};
