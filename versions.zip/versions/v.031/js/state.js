
"use strict";

window.State = {
  page:"home",
  mode:"pre",
  current:0,
  answers:{},
  learning:false,
  before:null,
  after:null,

  init(){
    try{
      const saved=JSON.parse(localStorage.getItem("vibe")||"{}");
      Object.assign(this,saved);
    }catch(e){
      console.warn("저장 데이터 초기화",e);
    }
  },

  save(){
    const data={
      learning:this.learning,
      before:this.before,
      after:this.after
    };
    localStorage.setItem("vibe",JSON.stringify(data));
  },

  reset(){
    this.current=0;
    this.answers={};
  }
};
