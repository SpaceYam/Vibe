
"use strict";

window.App = {
  render(){
    Exam.grid?.destroy();
    Exam.grid=null;
    Report.destroy();

    let html="";

    switch(State.page){
      case "assessment":
        html=Exam.render();
        break;

      case "learning":
        html=this.learning();
        break;

      case "report":
        html=Report.render();
        break;

      default:
        html=this.home();
    }

    document.getElementById("app").innerHTML=`
      <header class="topbar">
        <div class="logo">VIBE<span>SCHOOL</span></div>
        <nav>
          <button data-action="home">홈</button>
          <button data-action="learning">학습</button>
          <button data-action="report">리포트</button>
        </nav>
      </header>
      <main>${html}</main>
      <footer>VIBE SCHOOL © 2026 · AI LEARNING ACADEMY</footer>
    `;

    if(State.page==="assessment")Exam.initGrid();
    if(State.page==="report")Report.init();
  },

  home(){
    return `
      <div class="card">
        <span class="tag">AI PERSONALIZED ACADEMY</span>
        <h1>나의 AI 역량을 진단하고 성장시키세요.</h1>
        <p class="muted">
          역량 진단부터 실전 바이브코딩까지
          나만의 학습 여정을 시작합니다.
        </p>
        <div class="grid">
          <div class="stat">
            <strong>01</strong>
            <span>역량 진단</span>
          </div>
          <div class="stat">
            <strong>02</strong>
            <span>맞춤 학습</span>
          </div>
          <div class="stat">
            <strong>03</strong>
            <span>성과 분석</span>
          </div>
        </div>
      </div>

      <div class="card">
        <h2>학습 및 진단 현황</h2>
        <p>사전 진단: ${State.before?"완료":"미완료"}</p>
        <p>학습: ${State.learning?"완료":"진행 전"}</p>
        <p>사후 진단: ${State.after?"완료":"미완료"}</p>
        <div class="actions">
          <button class="btn primary"
            data-action="pre"
            ${State.before?"disabled":""}>
            사전 진단 시작
          </button>
          <button class="btn teal"
            data-action="learning">
            학습 시작하기
          </button>
        </div>
        ${State.before?`
          <p class="muted">사전 진단 점수: ${State.before.total}점</p>`:""}
      </div>

      ${State.after?`
        <div class="card">
          <h2>학습 성과 확인</h2>
          <button class="btn teal" data-action="report">
            최종 리포트 확인
          </button>
        </div>`:""}
    `;
  },

  learning(){
    return `
      <div class="card">
        <span class="tag">LEARNING ROADMAP</span>
        <h1>AI 바이브코딩 학습</h1>
        <p class="muted">
          사전 진단 결과를 바탕으로 학습을 진행하세요.
        </p>
      </div>

      ${[
        ["AI와 생성형 AI","AI 기본 개념 및 활용"],
        ["프롬프트 엔지니어링","역할, 목표, 맥락, 조건"],
        ["HTML / CSS","웹페이지 구조 및 디자인"],
        ["JavaScript","변수, 함수, 이벤트, DOM"],
        ["웹 프로젝트","실전 웹 애플리케이션 제작"]
      ].map((x,i)=>`
        <div class="card">
          <div class="row between">
            <div>
              <span class="tag">STEP 0${i+1}</span>
              <h3>${x[0]}</h3>
              <p class="muted">${x[1]}</p>
            </div>
            <span>${State.learning?"✓":""}</span>
          </div>
        </div>
      `).join("")}

      <div class="card">
        <h2>학습 완료</h2>
        <p class="muted">
          실제 교육 콘텐츠와 프로젝트를 모두 학습한 후
          완료 처리하세요.
        </p>
        <button class="btn teal"
          data-action="complete"
          ${!State.before||State.learning?"disabled":""}>
          학습 완료 처리
        </button>
        <button class="btn primary"
          data-action="after"
          ${!State.learning?"disabled":""}>
          사후 진단 시작
        </button>
      </div>
    `;
  },

  renderQuestion(){
    const el=document.getElementById("questionArea");
    if(el){
      const q=DB.questions[State.current];
      el.innerHTML=Exam.questionHTML(
        q,
        State.answers[q.id-1]!==undefined,
        State.answers[q.id-1]
      );
    }
  },

  toast(message){
    const el=document.getElementById("toast");
    el.textContent=message;
    el.classList.add("show");
    clearTimeout(this.toastTimer);
    this.toastTimer=setTimeout(
      ()=>el.classList.remove("show"),2300
    );
  },

  modal(title,message,onConfirm){
    const el=document.getElementById("modal");
    el.innerHTML=`
      <div class="modal-box">
        <h2>${title}</h2>
        <p>${message}</p>
        <div class="modal-actions">
          <button class="btn outline" data-action="cancel">
            취소
          </button>
          <button class="btn primary" data-action="confirm">
            확인
          </button>
        </div>
      </div>`;
    el.classList.add("show");
    this.confirmAction=onConfirm;
  },

  closeModal(){
    document.getElementById("modal").classList.remove("show");
    this.confirmAction=null;
  },

  init(){
    State.init();

    document.addEventListener("click",e=>{
      const b=e.target.closest("[data-action]");
      if(!b)return;

      const action=b.dataset.action;
      const index=Number(b.dataset.index);

      switch(action){
        case "home":
          State.page="home";
          this.render();
          break;

        case "pre":
          Exam.start("pre");
          break;

        case "after":
          Exam.start("after");
          break;

        case "learning":
          State.page="learning";
          this.render();
          break;

        case "report":
          State.page="report";
          this.render();
          break;

        case "answer":
          Exam.answer(index);
          break;

        case "prev":
          Exam.select(State.current-1);
          break;

        case "next":
          Exam.select(State.current+1);
          break;

        case "finish":
          this.modal(
            "시험을 제출할까요?",
            "제출 후에는 답변을 수정할 수 없습니다.",
            ()=>Exam.finish()
          );
          break;

        case "complete":
          this.modal(
            "학습 완료",
            "전체 학습 과정을 완료했습니까?",
            ()=>{
              State.learning=true;
              State.save();
              this.closeModal();
              this.render();
              this.toast("학습 완료!");
            }
          );
          break;

        case "confirm":
          this.confirmAction?.();
          break;

        case "cancel":
          this.closeModal();
          break;
      }
    });

    this.render();
  }
};

document.addEventListener("DOMContentLoaded",()=>App.init());
