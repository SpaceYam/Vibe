
"use strict";

window.Exam = {
  grid:null,

  start(mode){
    if(mode==="after" && !State.learning){
      App.toast("학습을 먼저 완료해 주세요.");
      return;
    }
    State.mode=mode;
    State.reset();
    State.page="assessment";
    App.render();
  },

  select(i){
    if(i<0 || i>=DB.questions.length)return;
    State.current=i;
    App.render();
  },

  answer(n){
    if(State.answers[State.current]!==undefined)return;
    State.answers[State.current]=n;
    this.grid?.refreshCells({force:true});
    App.toast("답변이 저장되었습니다.");
    App.renderQuestion();
  },

  score(){
    const result={total:0,domains:{}};
    DB.domains.forEach(d=>{
      const qs=DB.questions.filter(q=>q.domain===d);
      const correct=qs.filter(q=>
        State.answers[q.id-1]===q.answer
      ).length;
      result.domains[d]=Math.round(correct/qs.length*100);
      result.total+=correct;
    });
    result.total=Math.round(result.total/DB.questions.length*100);
    return result;
  },

  finish(){
    if(Object.keys(State.answers).length!==20){
      App.toast("모든 문제를 풀어 주세요.");
      return;
    }

    const result=this.score();
    if(State.mode==="pre")State.before=result;
    else State.after=result;

    State.save();
    App.closeModal();

    if(State.mode==="pre"){
      State.page="learning";
      App.render();
      App.toast("사전 진단이 완료되었습니다.");
    }else{
      State.page="report";
      App.render();
      App.toast("사후 진단이 완료되었습니다.");
    }
  },

  render(){
    const q=DB.questions[State.current];
    const done=State.answers[q.id-1]!==undefined;
    const completed=Object.keys(State.answers).length;
    const value=State.answers[q.id-1];

    return `
      <div class="card">
        <div class="row between">
          <h1>${State.mode==="pre"?"사전 역량 진단":"사후 역량 진단"}</h1>
          <span class="tag">${completed}/20 완료</span>
        </div>
        <p class="muted">
          문항별로 신중하게 답변하세요.
          제출한 답변은 변경할 수 없습니다.
        </p>
        <div class="progress">
          <span style="width:${completed/20*100}%"></span>
        </div>
      </div>

      <div class="card">
        <div id="questionArea">
          ${this.questionHTML(q,done,value)}
        </div>
        <div class="actions">
          <button class="btn outline" data-action="prev"
            ${State.current===0?"disabled":""}>← 이전</button>
          <button class="btn primary" data-action="next">
            다음 문제 →
          </button>
        </div>
      </div>

      <div class="card">
        <div class="row between">
          <h3>전체 문제 목록</h3>
          <span class="muted">완료한 문제 ✓</span>
        </div>
        <div id="questionGrid" class="ag-theme-quartz"></div>
        <div class="actions">
          <button class="btn outline" data-action="home">나가기</button>
          <button class="btn teal" data-action="finish">시험 제출</button>
        </div>
      </div>`;
  },

  questionHTML(q,done,value){
    return `
      <div class="question">
        <span class="tag">${q.domain} · ${q.type} · ${q.difficulty}</span>
        <h2>Q${q.id}. ${q.title}</h2>
        <p class="muted">정답을 하나 선택하세요.</p>
        <div class="options">
          ${q.options.map((v,i)=>`
            <button class="option
              ${value===i?"selected":""}"
              data-action="answer" data-index="${i}"
              ${done?"disabled":""}>
              ${String.fromCharCode(65+i)}. ${v}
              ${done&&value===i?" ✓":""}
            </button>
          `).join("")}
        </div>
        ${done?`
          <p class="muted">
            ${value===q.answer?"정답입니다.":"오답입니다."}
            ${q.explanation}
          </p>`:""}
      </div>`;
  },

  initGrid(){
    const el=document.getElementById("questionGrid");
    if(!el)return;
    this.grid?.destroy();
    this.grid=agGrid.createGrid(el,{
      rowData:DB.questions.map((q,i)=>({
        no:i+1,domain:q.domain,type:q.type,
        status:State.answers[i]!==undefined?"✓":"미완료"
      })),
      columnDefs:[
        {field:"no",headerName:"번호",width:85},
        {field:"domain",headerName:"평가 영역",flex:1},
        {field:"type",headerName:"유형",width:100},
        {
          field:"status",headerName:"완료",
          width:105,
          cellRenderer:p=>p.value==="✓"
            ?'<span style="color:#398b82;font-weight:bold">✓ 완료</span>'
            :'<span style="color:#8190a3">미완료</span>'
        }
      ],
      defaultColDef:{sortable:true,resizable:true},
      rowSelection:undefined,
      suppressCellFocus:true,
      onRowClicked:p=>this.select(p.data.no-1)
    });
  }
};
